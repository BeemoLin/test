<?php require_once('Connections/connSQL.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_Recordset1 = 10;
$pageNum_Recordset1 = 0;
if (isset($_GET['pageNum_Recordset1'])) {
  $pageNum_Recordset1 = $_GET['pageNum_Recordset1'];
}
$startRow_Recordset1 = $pageNum_Recordset1 * $maxRows_Recordset1;

mysql_select_db($database_connSQL, $connSQL);
$query_Recordset1 = "SELECT * FROM food ORDER BY food_date DESC";
$query_limit_Recordset1 = sprintf("%s LIMIT %d, %d", $query_Recordset1, $startRow_Recordset1, $maxRows_Recordset1);
$Recordset1 = mysql_query($query_limit_Recordset1, $connSQL) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);

if (isset($_GET['totalRows_Recordset1'])) {
  $totalRows_Recordset1 = $_GET['totalRows_Recordset1'];
} else {
  $all_Recordset1 = mysql_query($query_Recordset1);
  $totalRows_Recordset1 = mysql_num_rows($all_Recordset1);
}
$totalPages_Recordset1 = ceil($totalRows_Recordset1/$maxRows_Recordset1)-1;

$queryString_Recordset1 = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_Recordset1") == false && 
        stristr($param, "totalRows_Recordset1") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_Recordset1 = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_Recordset1 = sprintf("&totalRows_Recordset1=%d%s", $totalRows_Recordset1, $queryString_Recordset1);
$query_Recordset1 = "SELECT * FROM food ORDER BY food_id DESC";
$Recordset1 = mysql_query($query_Recordset1, $connSQL) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>首頁</title>
<style type="text/css">
<!--
body {
	background-color: #000;
	background-image: url();
	background-repeat: no-repeat;
	color: #FFF;
}
.a {
	background: url(file:///E|/myphp/img/%E7%89%A9%E7%AE%A1%E9%9B%B6%E4%BB%B6/%E8%83%8C%E6%99%AF.gif) repeat-x center;
}
.c {
	background: url(file:///E|/myphp/img/111.jpg) repeat-x;
}
.b {
	background: url(file:///E|/myphp/img/%E7%89%A9%E7%AE%A1%E9%9B%B6%E4%BB%B6/%E8%83%8C%E6%99%AF.gif) repeat-x top;
	text-align: center;
}
.d {
	background: url(file:///E|/myphp/img/%E7%89%A9%E7%AE%A1%E9%9B%B6%E4%BB%B6/%E4%B8%8B%E9%9D%A2.gif) repeat-x center;
}
.white {
	color: #FFF;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
//-->
</script>
<link href="CSS/link.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
#apDiv1 {
	position:relative;
	width:161px;
	height:27px;
	z-index:1;
	left: 0px;
	top: 0px;
	visibility: hidden;
}
-->
</style>
</head>

<body onload="MM_preloadImages('img/picture/picture/BTN/btn_紫_社區公告.gif','img/picture/picture/BTN/btn_紫_意見反應.gif','img/picture/picture/BTN/btn_紫_食衣住行.gif','img/picture/picture/BTN/btn_紫_公設預約.gif','img/picture/picture/BTN/btn_紫_社區剪影.gif','img/picture/picture/BTN/btn_紫_線上報修.gif','img/picture/picture/BTN/btn_紫_收支結算.gif')">
<table width="800" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th height="97" rowspan="2" scope="row"><img src="img/BTN/LOGO.gif" width="165" height="50" /></th>
    <th width="100" height="97" rowspan="2" scope="row">&nbsp;</th>
    <th width="100" height="97" rowspan="2" scope="row">&nbsp;</th>
    <th width="100" height="97" rowspan="2" scope="row">&nbsp;</th>
    <th width="100" height="48" scope="row">&nbsp;</th>
    <th width="150" height="48" scope="row">&nbsp;</th>
  </tr>
  <tr>
    <th height="49" scope="row">&nbsp;</th>
    <th height="49" class="white" scope="row"><a href="index2.php"><img src="img/picture2/HOME.gif" width="18" height="18" border="0" align="absmiddle" />首頁</a></th>
  </tr>
  <tr>
    <th height="57" colspan="6" style="background-position: center; background-image: url(img/before/2.jpg);" scope="row"><table width="800" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="142"><a href="announcement.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image4','','img/picture/picture/BTN/btn_紫_社區公告.gif',1)"><img src="img/picture/picture/BTN/btn_灰_社區公告.gif" name="Image4" width="100" height="30" border="0" align="right" id="Image4" /></a></td>
        <td width="100"><a href="opinion.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image5','','img/picture/picture/BTN/btn_紫_意見反應.gif',1)"><img src="img/picture/picture/BTN/btn_灰_意見反應.gif" name="Image5" width="100" height="30" border="0" id="Image5" /></a></td>
        <td width="100"><a href="order.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image7','','img/picture/picture/BTN/btn_紫_公設預約.gif',1)"><img src="img/picture/picture/BTN/btn_灰_公設預約.gif" name="Image7" width="100" height="30" border="0" id="Image7" /></a></td>
        <td width="100"><a href="food.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image6','','img/picture/picture/BTN/btn_紫_食衣住行.gif',1)"><img src="img/picture/picture/BTN/btn_灰_食衣住行.gif" name="Image6" width="100" height="30" border="0" id="Image6" /></a></td>
        <td width="100"><a href="photos.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image8','','img/picture/picture/BTN/btn_紫_社區剪影.gif',1)"><img src="img/picture/picture/BTN/btn_灰_社區剪影.gif" name="Image8" width="100" height="30" border="0" id="Image8" /></a></td>
        <td width="100"><a href="money.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image9','','img/picture/picture/BTN/btn_紫_收支結算.gif',1)"><img src="img/picture/picture/BTN/btn_灰_收支結算.gif" name="Image9" width="100" height="30" border="0" id="Image9" /></a></td>
        <td width="158"><a href="online.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image10','','img/picture/picture/BTN/btn_紫_線上報修.gif',1)"><img src="img/picture/picture/BTN/btn_灰_線上報修.gif" name="Image10" width="100" height="30" border="0" align="left" id="Image10" /></a></td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th height="386" colspan="6" scope="row"><table width="800" height="384" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="57" height="384"><p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p></td>
        <td width="743" height="384" valign="middle" style="background-position: right; background-repeat: no-repeat; background-image: url(img/before/picture1.gif);"><table width="220" border="0" align="left" cellpadding="0" cellspacing="0">
          <tr>
            <th width="100" height="100" scope="row">&nbsp;</th>
            <td width="20">&nbsp;</td>
            <td width="100" height="100">&nbsp;</td>
          </tr>
          <tr>
            <th height="1" scope="row">&nbsp;</th>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <th width="100" height="100" scope="row">&nbsp;</th>
            <td>&nbsp;</td>
            <td width="100" height="100">&nbsp;</td>
          </tr>
          <tr>
            <th scope="row">&nbsp;</th>
            <td>&nbsp;</td>
            <td valign="middle">&nbsp;</td>
          </tr>
          <tr>
            <th width="100" height="100" scope="row">&nbsp;</th>
            <td>&nbsp;</td>
            <td width="100" height="100">&nbsp;</td>
          </tr>
        </table>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <th width="78%" height="27" scope="row">ggg<a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show')"><img src="img/picture6/star.gif" width="15" height="15" border="0" /></a></th>
              <th width="22%" scope="row">&nbsp;</th>
            </tr>
          </table>
          <div id="apDiv1">ffff</div></td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th height="47" colspan="6" style="background-position: center; background-image: url(img/before/1.jpg);" scope="row">&nbsp;</th>
  </tr>
</table>
</body>
</html>
