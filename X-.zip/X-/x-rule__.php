<?php require_once('Connections/connSQL.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **

$logoutAction = 'logout.php';

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "admin,member";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_RecUser = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_RecUser = $_SESSION['MM_Username'];
}
mysql_select_db($database_connSQL, $connSQL);
$query_RecUser = sprintf("SELECT m_id, m_name, m_nick, m_username FROM memberdata WHERE m_username = %s", GetSQLValueString($colname_RecUser, "text"));
$RecUser = mysql_query($query_RecUser, $connSQL) or die(mysql_error());
$row_RecUser = mysql_fetch_assoc($RecUser);
$totalRows_RecUser = mysql_num_rows($RecUser);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>規約辦法</title>
<style type="text/css">
<!--
body {
	background-image: url();
	background-repeat: no-repeat;
	margin-left: 0px;
	margin-top: 0px;
	background-color: #000;
	font-family: "微軟正黑體";
	color: #FFF;
}
.all {
	background-image: url(img/third/backgrondreal.jpg);
}
.white {
	color: #FFF;
	font-family: "微軟正黑體";
}
-->
</style>
<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
//-->
</script>
<style type="text/css">
<!--
a:link {
	font-family: "微軟正黑體";
	color: #FFF;
}
a:visited {
	font-family: "微軟正黑體";
	color: #FFF;
}
a:hover {
	font-family: "微軟正黑體";
	color: #FFF;
}
.white1 {color: #FFF;
	font-family: "微軟正黑體";
}
#a1 {	height: 95px;
	width: 10px;
	float: left;
}
#a10 {	height: 95px;
	width: 40px;
	float: right;
}
#a2 {	height: 95px;
	width: 90px;
	float: left;
}
#a3 {	height: 95px;
	width: 90px;
	float: left;
}
#a4 {	height: 95px;
	width: 90px;
	float: left;
}
#a5 {	height: 95px;
	width: 90px;
	float: left;
}
#a6 {	height: 95px;
	width: 90px;
	float: left;
}
#a7 {	height: 95px;
	width: 90px;
	float: left;
}
#a8 {	height: 95px;
	width: 90px;
	float: left;
}
#a9 {	height: 95px;
	width: 90px;
	float: left;
}
#allpic {	background-image: url(img/beforepic/backgrondreal.jpg);
	height: 580px;
	width: 770px;
}
#apDiv1 {	position:relative;
	width:32px;
	height:73px;
	z-index:1;
	left: 0px;
	top: 10px;
}
#apDiv2 {	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
	left: -250px;
	top: 77px;
	visibility: hidden;
}
#pic1 {	height: 75px;
	width: 770px;
}
#pic2 {	height: 100px;
	width: 770px;
}
#pic3 {	height: 390px;
	width: 770px;
	background-repeat: no-repeat;
	background-position: left;
	background-image: url(img/beforepic/picture.gif);
}
#pic3_left {	float: left;
	height: 390px;
	width: 10px;
}
#pic3_right {	float: right;
	height: 390px;
	width: 760px;
}
#pic4 {	background-image: url(img/beforepic/dn_bar.gif);
	height: 20px;
	width: 770px;
}
#title {	float: left;
	height: 65px;
	width: 175px;
	background-image: url(img/third/LOGO.gif);
	background-repeat: no-repeat;
	background-position: right center;
}
#title2 {	float: left;
	height: 65px;
	width: 180px;
	background-image: url(img/beforepic/1.gif);
	background-repeat: no-repeat;
	background-position: right center;
}
#title3 {	float: right;
	height: 75px;
	width: 300px;
}
#title3_left {	float: left;
	height: 75px;
	width: 190px;
}
#title3_left_down {	height: 37px;
	width: 190px;
}
#title3_left_up {	height: 37px;
	width: 190px;
}
#title3_right {	float: right;
	height: 75px;
	width: 110px;
}
#title3_right_down {	height: 37px;
	width: 110px;
}
#title3_right_up {	height: 37px;
	width: 110px;
}
-->
</style>
</head>

<body onload="MM_preloadImages('img/third/btn_ bulletin_dn.gif','img/third/btn_opinion_dn.gif','img/third/btn_equipment_dn.gif','img/third/btn_share_dn.gif','img/third/btn_food_dn.gif','img/third/btn_photo_dn.gif','img/third/btn_mony_dn.gif','img/third/btn_fix_dn.gif','img/third/rule_dn.gif','img/third/choose_dn.gif','img/third/arrow_up(3).gif','img/third/btn_list_dn.gif','img/third/btn_rule_dn.gif','img/third/btn_info_dn.gif')">
<table border="0" align="center" cellpadding="0" cellspacing="0" id="allpic">
  <tr>
    <td height="75"><table border="0" cellpadding="0" cellspacing="0" id="pic1">
      <tr>
        <td><table border="0" cellpadding="0" cellspacing="0" id="title3">
          <tr>
            <td><table border="0" cellpadding="0" cellspacing="0" id="title3_left">
              <tr>
                <td><table border="0" cellpadding="0" cellspacing="0" id="title3_left_up">
                  <tr>
                    <td><img src="img/third/green_yes.gif" alt="" width="30" height="30" align="absbottom" /><span class="white1"><span class="white"><?php echo $row_RecUser['m_username']; ?></span><img src="img/life2/HI.gif" alt="" width="50" height="30" align="absbottom" /></span></td>
                  </tr>
                </table>
                  <table border="0" cellpadding="0" cellspacing="0" id="title3_left_down">
                    <tr>
                      <td><img src="img/third/in.gif" alt="" width="30" height="30" align="absbottom" /><a href="<?php echo $logoutAction ?>"><img src="img/life2/guest_out.gif" alt="" width="80" height="30" border="0" align="absbottom" /></a></td>
                    </tr>
                  </table></td>
              </tr>
            </table>
              <table border="0" cellpadding="0" cellspacing="0" id="title3_right">
                <tr>
                  <td><table border="0" cellpadding="0" cellspacing="0" id="title3_right_up">
                    <tr>
                      <td><a href="indexre.php?<?php echo "m_username=".urlencode($row_RecUser['m_username']) ?>"><img src="img/BTN/re.gif" alt="" width="110" height="30" border="0" /></a></td>
                    </tr>
                  </table>
                    <table border="0" cellpadding="0" cellspacing="0" id="title3_right_down">
                      <tr>
                        <td><img src="img/third/home.gif" alt="" width="30" height="30" align="absbottom" /><a href="index2.php"><img src="img/life2/FP.gif" alt="" width="50" height="30" border="0" align="absbottom" /></a></td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
          </tr>
        </table>
          <table border="0" cellpadding="0" cellspacing="0" id="title">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="title2">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="100"><table border="0" cellpadding="0" cellspacing="0" id="pic2">
      <tr>
        <td><table border="0" cellpadding="0" cellspacing="0" id="a10">
          <tr>
            <td><div id="apDiv1">
              <div id="apDiv2">
                <table width="290" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <th width="5" align="left" valign="top" bgcolor="#000000" scope="row"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side.gif" alt="a" width="3" height="95" vspace="0" border="0" align="left" /></a></th>
                    <td height="95" bgcolor="#000000"><a href="QandA.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image15','','img/third/btn_list_dn.gif',1)"><img src="img/third/btn_list_up.gif" alt="a" name="Image15" width="90" height="90" border="0" id="Image15" /></a></td>
                    <td width="5" bgcolor="#000000">&nbsp;</td>
                    <td bgcolor="#000000"><a href="rule.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image17','','img/third/btn_rule_dn.gif',1)"><img src="img/third/btn_rule_up.gif" alt="a" name="Image17" width="90" height="90" border="0" id="Image17" /></a></td>
                    <td width="5" bgcolor="#000000">&nbsp;</td>
                    <td bgcolor="#000000"><a href="info.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image16','','img/third/btn_info_dn.gif',1)"><img src="img/third/btn_info_up.gif" alt="a" name="Image16" width="90" height="90" border="0" id="Image16" /></a></td>
                    <td width="5" bgcolor="#000000"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side.gif" alt="a" width="3" height="95" vspace="0" border="0" align="right" /></a></td>
                  </tr>
                  <tr>
                    <th height="3" colspan="7" align="left" valign="top" scope="row"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side2.gif" alt="a" width="290" height="3" border="0" /></a></th>
                  </tr>
                  <tr>
                    <th height="9" colspan="7" align="center" valign="top" scope="row">&nbsp;</th>
                  </tr>
                </table>
              </div>
              <a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image24','','img/third/arrow_up(3).gif',1)"><img src="img/third/arrow_dn(3).gif" alt="" name="Image24" width="30" height="70" border="0" id="Image24" onmousedown="MM_showHideLayers('apDiv2','','show')" /></a></div></td>
          </tr>
        </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a1">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a2">
            <tr>
              <td><a href="announcement.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image1','','img/third/btn_ bulletin_dn.gif',1);MM_showHideLayers('apDiv2','','hide')"><img src="img/third/btn_ bulletin_up.gif" alt="" name="Image1" width="87" height="87" border="0" id="Image1" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a3">
            <tr>
              <td><a href="opinion.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image101','','img/third/btn_opinion_dn.gif',1);MM_showHideLayers('apDiv2','','hide')"><img src="img/third/btn_opinion_up.gif" alt="" name="Image101" width="87" height="87" border="0" id="Image101" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a4">
            <tr>
              <td><a href="order.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image111','','img/third/btn_equipment_dn.gif',1);MM_showHideLayers('apDiv2','','hide')"><img src="img/third/btn_equipment_up.gif" alt="" name="Image111" width="87" height="87" border="0" id="Image111" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a5">
            <tr>
              <td><a href="share.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image121','','img/third/btn_share_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_share_up.gif" alt="" name="Image121" width="87" height="87" border="0" id="Image121" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a6">
            <tr>
              <td><a href="life.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image131','','img/third/btn_food_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_food_up.gif" alt="" name="Image131" width="87" height="87" border="0" id="Image131" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a7">
            <tr>
              <td><a href="photos.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image141','','img/third/btn_photo_dn.gif',1);MM_showHideLayers('apDiv2','','hide')"><img src="img/third/btn_photo_up.gif" alt="" name="Image141" width="87" height="87" border="0" id="Image141" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a8">
            <tr>
              <td><a href="money.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image151','','img/third/btn_mony_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_mony_up.gif" alt="" name="Image151" width="87" height="87" border="0" id="Image151" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a9">
            <tr>
              <td><a href="online.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image161','','img/third/btn_fix_dn.gif',1)"><img src="img/third/btn_fix_up.gif" alt="" name="Image161" width="87" height="87" border="0" id="Image161" /></a></td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="390"><table border="0" cellpadding="0" cellspacing="0" id="pic3">
      <tr>
        <td><table border="0" cellpadding="0" cellspacing="0" id="pic3_right">
          <tr>
            <td align="left" valign="top"><table width="470" border="0" align="left" cellpadding="0" cellspacing="0">
              <tr>
                <th width="485" height="360" align="left" style="width: 470px; height: 385px; position: absolute; overflow: auto; font-family: '微軟正黑體'; color: #FFF;" scope="row"><p><strong>第一章　<a href="#A1">認識親家愛敦閣</a></strong><a name="A" id="A"></a></p>
                  <p><strong>第二章 親家愛敦閣社區管理辦法</strong></p>
                  <p> 　　<strong>Ⅰ</strong>、<a href="#B1">機車停車場使用及管理辦法</a></p>
                  <p> 　　<strong>Ⅱ</strong>、<a href="#B2">店鋪廣告看板使用管理辦法</a></p>
                  <p>　　Ⅲ、<a href="#B3">門禁安全管理辦法</a></p>
                  <p>　　<strong>Ⅳ</strong>、<a href="#B4">公共設施使用管理辦法</a></p>
                  <p>　　<strong>Ⅴ</strong>、<a href="#B5">外觀管理辦法</a></p>
                  <p>　　<strong>Ⅵ</strong>、<a href="#B6">租售管理辦法</a></p>
                  <p>　　<strong>Ⅶ</strong>、<a href="#B7">仲介管理辦法</a></p>
                  <p>　　<strong>Ⅷ</strong>、<a href="#B8">電子公佈欄管理辦法</a></p>
                  <p>　　<strong>Ⅸ</strong>、<a href="#B9">遷入及遷出管理辦法</a></p>
                  <p>　　Ⅹ、<a href="#B10">裝潢施工管制管理辦法</a></p>
                  <p>　　<strong>〡</strong>、<a href="#B11">停車場使用及管理辦法</a></p>
                  <p>　　<strong>〢、</strong><a href="#B12">管理費收支辦法</a></p>
                  <p>　　<strong>〣、</strong><a href="#B13">環境整潔管理辦法</a></p>
                  <p>　　<a href="#B14">水療池使用管理規則</a></p>
                  <p>　　<a href="#B15">沙發接待交誼廳使用管理規則</a></p>
                  <p>　　<a href="#B16">哈瓦那 LOUNGE使用管理規則</a></p>
                  <p> 　　<a href="#B17">健身房使用管理規則</a></p>
                  <p>　　<a href="#B18">游泳池使用管理規則</a></p>
                  <p>　　<a href="#B19">蒸氣室、烤箱室使用管理規則</a></p>
                  <p>　　<a href="#B20">親子兒童遊戲館使用管理規則</a></p>
                  <p>　　<a href="#B21">環球視聽電影院使用管理規則</a></p>
                  <p>　　<a href="#B22">籃球場使用管理規則</a></p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <hr />
                  <p>&nbsp;</p>
                  <p>第一章　<strong>認識親家愛敦閣<a name="A1" id="A1"></a></strong>　　　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <ol>
                    <li><strong>遷入準備事項 </strong></li>
                    <li>住戶與公司辦妥交屋手續後，至社區管理中心，登記裝潢或遷入日期及住戶   </li>
                  </ol>
                  <p>    基本資料，以便安排各項事宜及建檔作為日後聯繫之用，所有資料均保密保 <br />
                    存之。 <br />
                    (二)住戶搬入傢俱時，請至管理中心申請或遷入所需之證件。 <br />
                    (三)住戶裝潢時： <br />
                    A.住(業)戶應於施工三日前至管理中心辦理下列手續： </p>
                  <ol>
                    <ol>
                      <ol>
                        <ol>
                          <li>填寫「裝修工程申請表」②簽訂「裝修工程切結書」③交付「裝修保證金」貳拾萬元整（「裝修保證金」以即期支票為主，支票抬頭：親嘉開發有限公司） </li>
                        </ol>
                      </ol>
                    </ol>
                  </ol>
                  <p>B.辦理施工手續需攜帶： <br />
                    ①裝修設計圖，不能破壞結構為主②施工工種名冊。 <br />
                    C.裝潢完成時，應申請完工檢查及退回保證金。 </p>
                  <p>&nbsp;</p>
                  <hr />
                  <p><strong>第二章 親家愛敦閣社區管理辦法</strong></p>
                  <p>　　<strong>Ⅰ</strong>、機車停車場使用及管理辦法<a name="B1" id="B1"></a> 　　　　　　　<a href="#A">回最上層</a></p>
                  <p>一.目的 </p>
                  <ol>
                    <li>為健全本社區機車停車場之使用與管理，以確保機車、人員之安全及停車場清潔與設備維護，特制定此辦法規範之。 </li>
                  </ol>
                  <p>(1) 出入管制 <br />
                    1.1本社區停車場採24小時全天候開放。 <br />
                    1.2機車憑遙控器進出。 <br />
                    (2)使用注意事項 <br />
                    2.1社區之機車停車位共二百零三位，(授權管理委員會訂定公告執行)。 <br />
                    2.2地下室機車位，禁止沖洗機車，只得擦拭，以免地面積水，造成行人滑倒。 <br />
                    2.3本機車停車場為社區之公共設施，區分所有權人不得轉租或借用於非本社區人員使 <br />
                    用。 <br />
                    2.4機車停車位僅供停放機車、重型機車或腳踏車使用，不得堆放物品或移作其它用途。 <br />
                    (3)本辦法經管理委員會審議通過後公佈實施，修訂時亦同。 </p>
                  <p>&nbsp;</p>
                  <p>　　<strong>Ⅱ</strong>、店鋪廣告看板使用管理辦法<a name="B2" id="B2"></a>　　　　　　　　<a href="#A">回最上層</a></p>
                  <ol>
                    <li>目的： </li>
                  </ol>
                  <p>為維護本社區整體景觀，特制定本辦法。 </p>
                  <ol>
                    <li>裝設申請： </li>
                    <li>本社區店面招牌之裝設，應合於本社區原規劃尺寸施作。 </li>
                  </ol>
                  <p>（二）申請裝設前，請將招牌尺寸及預定裝設位置圖提送管理委員會審核，經確認後始可裝設。 <br />
                    （三）建設公司代管期間提送建設公司業主代表審核，經確認後始可裝設。 <br />
                    （四）裝設前請依社區原設計提出申請許可，並將許可證明副本提供管理委員會存查。 </p>
                  <ol>
                    <li>注意事項： </li>
                    <li>未依規定之廣告招牌一經施作，如有違反本辦法相關規定者，業主代表及管理委員會得提出改善要求，經要求改善未自行處理者，業主代表及管理委員會得提報相關單位執行拆除作業，所需之費用及造成之損失由廣告物設立者自行負擔。 </li>
                    <li>未經規劃之處所不得自行設置及樹立廣告物，違者依法處理。 </li>
                    <li>廣告物所需使用之電力，應由廣告物設立者自行負擔，不得私接公用電源。 </li>
                  </ol>
                  <p>(四) 社區店面部分，限定不得做為或供做下列行業使用：如工廠、易燃易爆之化學品 <br />
                    儲藏所、色情理容院、賓館、按摩院、辦喪行業，產生空氣污染及噪音行業（如 <br />
                    機車修理等其他妨害公共安寧與秩序維護之行業）。 </p>
                  <ol>
                    <li>未盡事宜： </li>
                  </ol>
                  <p>本辦法經公告後生效，如有未盡事宜，經管理委員會修正後公告。 <br />
                    五、附則 <br />
                    (一)本辦法經管理委員會審議通過後公佈實施，修訂時亦同。，原買賣契約有規定者從其規定。 <br />
                    (二)本辦法如有增減修改之必要，授權管理委員會研議，並公告實施。 </p>
                  <p>&nbsp;</p>
                  <p>　　Ⅲ、門禁安全管理辦法<a name="B3" id="B3"></a>　　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>       一、目的 <br />
                    為維護本大樓公共秩序與安全，特訂定安全管制辦法。 <br />
                    二、公共秩序維護 <br />
                    （一）<u>噪音管制 </u><br />
                    所有音量應控制在不影響他人原則之下，如已妨礙他人，可依相關法令及住戶規約規定處罰之。 <br />
                    （二）<u>孩童管制 </u><br />
                    1、如經發現孩童私自在大樓遊蕩，管理人員得以留置於服務台，立即通知家長。 <br />
                    2、孩童出入，大人應負看管責任，不使其跑跳、大聲喧嚷或嬉戲。 <br />
                    <br />
                    （三）<u>動物管制</u> <br />
                    為維護本大樓之公共安全，本大樓嚴禁訪客攜入貓、狗等寵物，如經發現，管理員得以出面制止。 <br />
                    （四）<u>門禁管制 </u><br />
                    1、開放時間：<u> </u><br />
                    二十四小時管制；訪客須先登記，並經住戶同意後，依證件換領訪客專用感應卡片後始可進入。 <br />
                    2、出入管制： <br />
                    （1）大樓安全，人人有責，各住戶應提高警覺，小心防範。 <br />
                    （2）遇有可疑人物，應詢問其來由，並通知管理中心，以做應變。 <br />
                    （3）本社區各進出人口均設有門禁感應讀卡機，除規劃住戶卡外，尚有訪客專用卡、工作人員卡及臨時（備用）卡等感應卡管理；此可做電腦連線，並可設定新增、刪除或停用。 <br />
                    （五）<u>其他管制 </u><br />
                    1、車輛不得停放於禁止地區，違規者管理人員得予禁止或採取其他合理懲處措施。 <br />
                    2、地攤、小販不得於本大樓前營業，違者將報警處理。 <br />
                    3、各住戶不得於本大樓前吆喝或強行推銷，影響公共秩序。 <br />
                    4、送貨至本社區之貨車一律由地下室出入。 <br />
                    （六）<u>竊盜之防範與處理 </u><br />
                    1、防範措施： <br />
                    （1）放置金錢及貴重物品之抽屜櫃櫥，應加鎖小心保管。 <br />
                    （2）對講機、電話等，不可因室內裝潢而更換位置或封閉，以免影響日後安全及檢修工作。 <br />
                    （3）注意於大樓附近徘徊觀望之可疑人物，必要時注意其特徵並提高警覺。 <br />
                    2、處理辦法： <br />
                    （1）提高警覺、保持鎮定。 <br />
                    若發現宵小或盜賊侵入，應保持鎮定，以生命安全為要，詳記案發時間、地點及歹徒之特徵、衣著、口音及車號，並伺機報警、求救或突襲。 <br />
                    （2）保持現場 <br />
                    宵小或盜賊逃逸時，應將出事地點之一切物品保持原狀，切勿搬動或觸摸，以留待警察人員勘查。 <br />
                    （3）報警：立即向警察機關報案，並通知服務中心做緊急處理。 <br />
                    （4）善後 <br />
                    a、開列遺失物品清單，如名稱、數量、價值、特徵等。 <br />
                    b、將有關線索提供警察機關作偵查之參考，如歹徒之特徵、案發時間、案發經過、發現時間或任何案發前後之可疑事項。 <br />
                    c、儘可能協助破案，以免歹徒再度造訪。 <br />
                    （七）<u>意外事故之防範 </u><br />
                    1、防火： <br />
                    （1）煙蒂等火種應於熄滅後方可丟棄於適當場所。 <br />
                    （2）電機室、廚房、消防設備、瓦斯、石油、電器設備等，嚴禁煙火。 <br />
                    （3）嚴禁攜入易爆性或危險物品，若確有需要，應隔離保管，小心控制，注意儲存場所之通風，並作警示標誌與安全隔離。 <br />
                    （4）非經電力公司安全檢查，各公司行號不得私裝電線、電管。 <br />
                    （5）避免使用延長線，以防超負荷用電，插座電壓若與電器不符，切勿使用。 <br />
                    （6）本大樓內，嚴禁燃燒物品。 <br />
                    （7）梯間、門外、通道、走廊、出口、太平梯，嚴禁堆置物品。 <br />
                    （8）窗戶、通風口為空氣流通用，勿任意將其封死，影響空氣循環。 <br />
                    （9）內部裝潢時，注意勿將安全裝置、消防設備變更、移設、擋住或破壞。 <br />
                    （10）緊急逃生路線指標，勿任意拆卸。 <br />
                    2、停電處理： <br />
                    （1）發現停電情況，儘快通知服務中心停電地點。 <br />
                    （2）遇停電時保持鎮定，切勿點燃任何有機物品作為照明用途，如須用蠟燭照明，應小心留意，離開前先要確定蠟燭熄滅再將門窗上鎖。 <br />
                    （3）平常應隨時準備手電筒及緊急照明燈。 <br />
                    3、其他公共安全注意事項： <br />
                    （1）招牌或懸掛物應裝設妥當，如有搖晃情形，應即鎖緊。 <br />
                    （2）施工前，應設防布網或屏障設施，以免落石、物件擊中行人。 <br />
                    （3）施工後，應將垃圾及雜物及施工建材等處理，以防意外。 <br />
                    （4）遇有斷落電線，勿自行修理，應請專門人員整修之。 <br />
                    （5）勿以濕手碰觸插頭、插座或通電之電器用品。 <br />
                    （6）水塔、電機房等重地，請勿靠近。 <br />
                    （7）嚴禁在電梯內抽煙、破壞。 <br />
                    （8）任何公共設備皆須妥善使用，勿任意破壞或搬離。 <br />
                    三、附則 <br />
                    本辦法如有增減修改之必要，授權管理委員會研議，並公告實施。</p>
                  <p>&nbsp;</p>
                  <p>　　<strong>Ⅳ</strong>、公共設施使用管理辦法<a name="B4" id="B4"></a>　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>一、總則 <br />
                    為提供社區住戶良好之交誼及休閒環境，使社區公共設施能在妥善的維護下充分發揮其應有且安全之功效，促進所有住戶彼此間之交流及感情的和睦，並兼顧住戶權益，於『住戶規約』中訂定辦法，以為使用管理之依據。 <br />
                    二、經營與管理 <br />
                    本社區公共設施由管理委員會統籌一切經營與管理事宜，並由管理服務人員負責執行。凡進出公共設施及使用各項設施之人員，均須遵循本辦法之規定。（特殊使用狀況、時間限制可事先提出，經管委會許可） <br />
                    三、設施種類及使用辦法 <br />
                    本公共設施之各項設施如下： <br />
                    1、<strong>沙發接待交誼廳</strong>2、<strong>籃球場</strong>3.<strong> </strong><strong>健身房</strong>4.<strong> </strong><strong>游泳池</strong>5.<strong> </strong><strong>烤箱</strong>6.<strong> </strong><strong>蒸氣室7. 水療池8.親子互動生活館9. 親子兒童遊戲館10.  環球視聽電影院11. 哈瓦那LOUNGE</strong>。 <br />
                    四、使用辦法：各項公共設施使用說明如下 <br />
                    (一)本社區之各項公共設施僅供社區內住戶（含承租戶及其親友）使用，不對外開放。 <br />
                    (二)住戶使用各項設施時，須先至管理中心辦理登記，非住戶則須由住戶陪同，始得登記使用。 <br />
                    (三)進入各項設施，須遵守該室之設施使用規定及管理人員之說明及指導，以利設施之維護。 <br />
                    (四)本社區之各項設施，為求維持最佳使用狀態，管理人員可視休閒場地之大小及設備實施人數管制。 <br />
                    (五)基於安全考量，非經許可，除專業人員外，任何人不得對本社區之各項設施、器材及  <br />
                    設備做任何型式之更換與修繕動作，否則若有意外自行負責，所產生之損害亦應負賠償之責。 <br />
                    (六)遇特殊狀況（如颱風、停電）或器材設備保養、重大維修等不可抗拒之狀況而無法開 <br />
                    放時，管理中心須於事前以電子公佈欄公告讓住戶知悉。 <br />
                    (七)為兼顧全體住戶之權益，本社區公共設施使用及收費狀況於每月列表呈送管委會審查  <br />
                    ，並將收取之費用專款專用作為教師費及設施維修器材費用使用。 <br />
                    (八)各項公共設施之使用若有另行規劃其他用途或異動時，須專案提報管委會，經管委會 <br />
                    決議通過後方可實施。 <br />
                    (九)各使用人不得利用使用公共設施之便，從事不正當或經管委會認定不妥當之活動。 <br />
                    (十)禁止吸煙及帶任何寵物進入室內之公共設施，以維護其他住戶之權益。 <br />
                    (十一)各項公共設施開放時間若有異動或遇年節、特殊休假日、特殊情況時，可彈性調整開放時間並於事前公告住戶知悉。 <br />
                    (十二)本社區之各項公共設施管理細則，如後說明。 <br />
                    五、違規處置 <br />
                    （一）為維護其他使用者之權益，服務人員有權利要求違規之使用者停止使用各項公共設施，並將違規事實記錄及提報管理委員會裁定處理。 <br />
                    （二）損壞任何設施或器材等公共財產者，應照價賠償。 <br />
                    （三）非本社區住戶或其所帶領之親友及未經核准使用人員，管理人員得令其立即離開；不聽勸告者，將依私自侵入本社區，強制驅離現場。 <br />
                    （四）凡違反本辦法之規定者，除辦法內另有規定外，依「住戶規約」規定辦理。 <br />
                    六、附則 <br />
                    （一）本辦法由管理委員會議通過後公告實施。 <br />
                    （二）本辦法若有未盡事宜，得經由管理委員會議決議修訂之並公告實施。 </p>
                  <p>&nbsp;</p>
                  <p>　　<strong>Ⅴ</strong>、外觀管理辦法<a name="B5" id="B5"></a>　　　　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>一、目的 <br />
                    為維護本大樓建築形象、整體美觀及消防安全措施，進而提昇生活品質，訂定本辦法規範之。 <br />
                    二、法令規定 <br />
                    公寓法第八條規定：公寓大廈周圍上下、外牆面，樓頂平台及防空避難室，非依法令規定並經區分所有權人會議之決議，不得有變更構造、顏色、使用目的、設置廣告物或其他類似之行為。 <br />
                    三、罰則 <br />
                    公寓法第三十九條規定：住戶違反第八條關於公寓大廈變更使用之限制，經制止而無效者，得由主管機關處新台幣肆萬元以上貳拾萬元以下之罰款。 <br />
                    四、外觀管理規定 <br />
                    屬於本社區之外觀及公設，應按建方交屋時之現狀永久維護使用，如有任何裝設物，應遵守下列規定： <br />
                    （一）<u>空調主機</u>：依原設計師及起造人所規劃之位置統一安裝分離式空調主機，並由管理中心提供安裝配置圖供住戶參考。 <br />
                    （二）<u>陽台外移或陽台加窗</u>：除依建方統一考量位置施作或由管理服務中心所提供之位置樣式外，未經區分所有權人會議通過，不得有自行加設任何裝設物之行為。 <br />
                    （三）<u>安 全 窗</u>：除依建方規劃考量位置施作，或經區分所有權人會議通過且依統一材質、樣式與施工規範施作外，不得有自行加設任何裝設物之行為。 <br />
                    （四）不得於本社區之任何地方加建採光罩或其他影響之建材，如有使用上需要，須經區分所有權人會議通過，方可施作。 <br />
                    （五）上述裝設物如事後應恢復原狀時，由區分所有權人各自負責。 <br />
                    五、附則 <br />
                    1、本辦法未經區分所有權人會議決議時，原買賣契約有規定者從其規定。 <br />
                    2、本辦法如有增減修改之必要，授權管理委員會研議，並公告實施。 </p>
                  <p>&nbsp;</p>
                  <p>　　<strong>Ⅵ</strong>、租售管理辦法<a name="B6" id="B6"></a>　　　　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>一、目的 <br />
                    為維護本大樓形象，提昇生活品質，特訂定本辦法規範之。 <br />
                    二、辦法 <br />
                    （一）本大樓絕對禁止與色情、賭博、神壇及其他法令不許之相關行業承租或買售。 <br />
                    （二）本大樓為住家純住宅使用，禁止店頭式營業之行為（如髮廊、韻律中心、聯誼社、酒廊及KTV等）。 <br />
                    （三）屬於社區各業主戶內專有部份，限定不得做為或供做下列行業使用：如工廠、易燃易爆之化學品儲藏所、色情理容院、賓館、按摩院、辦喪行業，產生空氣污染及噪音行業（如機車修理等其他妨害公共安寧與秩序維護之行業）。 <br />
                    （四）請住戶慎選承租（購）人。 <br />
                    （五）住戶必須告知承租人，本說明書所列之住戶規約、管理辦法及說明，承租人必須無異議遵守。 <br />
                    （六）住戶應於承租人遷入前，將其背景資料以書面方式提送管理委員會備查。 <br />
                    （七）管理費應由承租雙方協議後定期繳交之，承租人如拒繳管理費用時，應由原區分所有權人繳交。 <br />
                    （八）所有權人因租售需要，必須張貼告示海報時，應依公佈欄使用須知規定使用之。 <br />
                    （九）任何租售海報不得張貼於本大樓外牆。 <br />
                    （十）任何租售海報文宣不得於屋內任何地方向外張貼。 <br />
                    三、附則 <br />
                    本辦法若有未盡事宜，得經管理委員會議決議後增減修訂，並公告實施。 </p>
                  <p>&nbsp;</p>
                  <p>　　<strong>Ⅶ</strong>、仲介管理辦法<a name="B7" id="B7"></a>　　　　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>一、目的 <br />
                    為維護本大樓形象，提昇生活品質，特訂定本辦法規範之。 <br />
                    二、辦法:所有權人委託仲介租售服務時，房屋仲介公司（人）及參訪之來賓，應注意社區隱 </p>
                  <ol>
                    <li>   私及安全，不得將社區做為銷售講習之用，避免影響住戶生活品質及環境整潔。 </li>
                    <li>   相關規定如下： </li>
                    <li>（1）委託銷售之房屋，必需完成交屋手續 或 取得正式產權，未交屋者除經建方同 </li>
                    <li>     確認，否則禁止仲介銷售。 </li>
                    <li>（2）仲介人員應備「委任授權書影本」，置管理中心備份存查，第一次應提示「委任授權書正本」，供管理人員核對查證；（授權書需明確標示房屋資料、委託期限、屋主簽章） </li>
                    <li>（3）管理人員依社區門禁管理規定，將「委任授權書影本」建檔存查並登錄管制簿 </li>
                    <li>冊，詳實記載「戶別、委託期限、仲介公司」，實施換證手續，以利帶看之管制。鑰匙、感應扣卡，儘量避免寄存管理中心。 </li>
                    <li>（4）帶看時段為AM09:30~11:30 PM14:30-17:30以整點或半點整為預約(帶看)時間(每組最長限30分鐘)其餘時間禁止帶看，每次不得超過二位仲介人員進入社區（不含參訪來賓），帶看期間需全程配帶識別證(帶)，帶看動線除各專有室內及停車場外，嚴禁參觀其他樓層；非經許可或開放，嚴禁參觀公設及拍照；並禁止吸煙、吃檳榔、喝酒等不良行為。 </li>
                    <li>（5）嚴禁於外牆及由室內專有部份之玻璃，由內向外張貼銷售海報，店面僅限於店面統一招牌範圍內，設計美觀之銷售看板，嚴禁其他張貼銷售海報、擺設立式看板等，嚴禁於社區內住戶信箱、公共區域，投遞、張貼、置放任何銷售資料。 </li>
                    <li>（6）違反本管理辦法之規定，經勸導後，仍不依相關規定辦理，禁止該人員進入本社區帶看。 </li>
                  </ol>
                  <p><strong>（三）附則： </strong><br />
                    本辦法若有未盡事宜，得經管理委員會議決後增減修訂，並公告實施。 </p>
                  <p>&nbsp;</p>
                  <p>　　<strong>Ⅷ</strong>、電子公佈欄管理辦法<a name="B8" id="B8"></a>　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>一、目的 <br />
                    本大樓設置公佈欄以便宣導及互通訊息，且為保持環境整潔，特訂定本辦法使用須知。 <br />
                    二、辦法 <br />
                    （一）<u>使用範圍 </u><br />
                    1、委員會對公共事務之宣導、公佈、通知等事項。 <br />
                    （二）<u>注意事項 </u><br />
                    1、本須知經委員會核准後，經主委用印後，公佈即日實施，如有任意在電子公告欄張貼者，本委員會將派員嚴格取締，以維護環境整潔。 <br />
                    2、本電子公佈欄啟用後，凡在本大樓內裝潢等廠商不得將廣告任意散發或張貼，一經發現應予銷毀，或送環保單位究辦。 <br />
                    三、附則 <br />
                    本辦法如有未盡事宜，得經管理委員會議決後增減修訂，並公告實施。 </p>
                  <p>&nbsp;</p>
                  <p>　　<strong>Ⅸ</strong>、遷入及遷出管理辦法<a name="B9" id="B9"></a>　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>一、目的 <br />
                    為維護本大樓之人員動態記錄，及避免破壞和污染情況產生，特訂定本辦法規範之。 <br />
                    二、遷入時 <br />
                    （一）住戶於遷入本社區時，應遵守本社區所定之規約辦法。 <br />
                    （二）住戶遷入同時必須提出「所有權證明」並填寫一份遷入住戶資料表，繳交至管理室以報管理委員會備檔資料。 <br />
                    （三）住戶如為承租戶在繳交遷入住戶資料時，須另檢附承租人之承租合約書及身份證影印本，供管理委員會存查。 <br />
                    （四）住戶於遷入時，裝潢須遵守施工管理辦法外，應要求施工者勿破壞本社區之公共設施，以維社區之正常運作。 <br />
                    （五）住戶請搬家公司或物品運送者，都須配合管理委員會規定的事項，並繳交遷入保證金5,000元整（遷入後檢查如無毀損公物則退回）；如有不聽指示者，管理人員有權利代管理委員會及其他住戶執行強制禁止行為。 <br />
                    三、遷出時 <br />
                    （一）住戶遷出本社區應至管理室填寫遷出資料，待管理委員會審核後，簽章認定之。 <br />
                    （二）凡住戶欲遷出時，請繳清管理費用；如有未繳清費用，管理委員會授權管理人員可斷絕非區分所有權人本人以外之所有服務，待費用繳清才予以放行。 <br />
                    （三）遷出時，請注意公共設施勿有破壞行為，如有毀壞公物則須照價賠償。 <br />
                    四、附則 <br />
                    本辦法如有增減修改之必要，授權管理委員會研議，並公告實施。 </p>
                  <p>&nbsp;</p>
                  <p>　　Ⅹ、裝潢施工管制管理辦法<a name="B10" id="B10"></a>　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <ol>
                    <li>目的 </li>
                  </ol>
                  <p>為維護本大樓結構安全、建築整體及外觀，為對住戶執行裝修工程之管理，特訂定本規定。 </p>
                  <p> 　２.申請程序 </p>
                  <p>應於施工三日前至管理委員會(或管理中心)辦理下列手續： <br />
                    填寫「裝修工程申請表」如附件一。 <br />
                    簽訂「裝修工程切結書」如附件二。 <br />
                    交付「裝修保證金」貳拾萬元整。 </p>
                  <p> 　３.竣工驗收程序 </p>
                  <p>住戶應於工程完竣並由管理中心會同驗收通過後，攜帶收據至管理中心辦理裝潢施工保證金退款之手續。 </p>
                  <p>　４.附則 </p>
                  <p>本辦法經管理委員會審議通過後公佈實施，修訂時亦同。 </p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>　　<strong>〡</strong>、停車場使用及管理辦法<a name="B11" id="B11"></a>　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>一、目的 </p>
                  <ol>
                    <li>為健全本社區停車場之使用與管理，以確保車輛、人員之安全及停車場清潔與設備維護，特制定此辦法規範之。 </li>
                    <li>&nbsp;</li>
                    <li>出入管制 </li>
                    <ol>
                      <li>本社區停車場採24小時全天候開放。 </li>
                      <li>自上午七時至九時及下午五時至七時車道鐵捲門開放，以柵欄機管制車輛進出，其   </li>
                    </ol>
                  </ol>
                  <p>餘時段車輛憑感應器進出。 </p>
                  <ol>
                    <li>&nbsp;</li>
                    <li>收費標準 </li>
                    <ol>
                      <li>平面車位每月應繳車位清潔費200元整。 </li>
                      <li>機械車位每月應繳車位清潔費400元整。(含電費補貼、保固期滿後之保養維護費)</li>
                      <li>收費標準如有變動，以”管理經費收支辦法”之規定為準。 </li>
                    </ol>
                  </ol>
                  <ol>
                    <li><strong>管理規定 </strong></li>
                  </ol>
                  <p>1.交屋後須持行照至管理室填單登錄車牌號碼輸入主控端車牌自動辨識系統，以利進出車輛之監控；另出入之車輛須配掛車位識別證於車窗明顯處後方得進入，以利識別，並遵從管理員指揮，循序進出。 <br />
                    2.住戶進出停車場遇有緊急情事發生或遭跟蹤、脅迫時，可藉由車輛遙控器之無限反脅迫求救系統，將警報訊號傳送至管理中心中央監控系提供住戶專屬之安全服務。 <br />
                    3.區分所有權人應就自己責任範圍內予以管理，不得向管理委員會或管理人員，請求車輛之事故、毀損、失竊或其他人身事故之損害賠償。 </p>
                  <ol>
                    <li>&nbsp;</li>
                    <li>使用注意事項 </li>
                    <ol>
                      <li>本停車場為地下六樓設施，計有汽車平面車位248位；機械車位94位。 </li>
                      <li>凡本停車場之汽車位所有權人及使用人，應憑本社區之停車識別證進入，並將證件置  </li>
                    </ol>
                  </ol>
                  <p>於前方玻璃之右下方。 </p>
                  <ol>
                    <ol>
                      <li>地下室停車場之車位，以一位停放一車為原則，不得侵佔他人之車位及通道。 </li>
                      <li>施工裝潢階段，未經區分所有人同意，至櫃臺簽立同意書，施工車輛不能停放地下 </li>
                    </ol>
                  </ol>
                  <p>室停車位，區分所有人依本身擁有停車位數量給該戶施工車停放，無者或超過者請 <br />
                    施工人員自己處理，不得停放地下室停車場。 </p>
                  <ol>
                    <ol>
                      <li>地下室停車場專供車輛停放使用，不得堆積雜物或供做其他用途，惟緊急避難不在 </li>
                    </ol>
                  </ol>
                  <p>此限。 </p>
                  <ol>
                    <ol>
                      <li>地下室停車場內，禁止沖洗車輛，只得擦拭，以免地面積水，造成行人滑倒。 </li>
                      <li>為維護地下室停車場之安全防範措施，人員一律禁止從地下斜坡道步行進出。 </li>
                      <li>本停車場為社區之公共設施，由區分所有權人依購屋合約事項行約定專用之權利， </li>
                    </ol>
                  </ol>
                  <p>所有權人不得轉租售於非本社區住戶之人員使用。 </p>
                  <ol>
                    <ol>
                      <li>裝卸貨物車輛進入車道前應先至管理室登記換證，進出時應注意限高、限重標示，並應儘快完成裝卸作業駛離現場，經管理室確認未損及停車設備時始得退還證件，若於裝卸貨物期間造成停車設備損壞，其損壞賠償責任由駕駛員付擔；卸貨時司機不得離開貨車，並應打亮警示燈，以免發生危險。 </li>
                      <li>貨車如承載物品疊高超過車道限高(2.1公尺)需先與管理室旁先行將部份貨物卸下，以分趟 </li>
                    </ol>
                  </ol>
                  <p>之方式將貨物載入停車場。 </p>
                  <ol>
                    <ol>
                      <li>汽車停車位僅供停放汽車使用，不得停放機車、腳 車、堆放物品或移作其它用途，車頭方向統一朝外。 </li>
                      <li>車輛於停車場拋錨時，應立即通知管理人員協助推離通道，以免妨礙其他車輛進出。 </li>
                      <li>進入本停車場之車輛維修人員，應由車主陪同，並先向管理服務中心辦理登記， </li>
                    </ol>
                  </ol>
                  <p>      於工作完成後，應立即離去，未登記者，不得進入車場維修車輛。 </p>
                  <ol>
                    <ol>
                      <li>地下室停車場內，不得任意丟棄垃圾、煙蒂，以維護社區之環境觀瞻。 </li>
                      <li>地下室停車場內，一律禁止儲存汽油及其他保養油料。 </li>
                      <li>停放於地下室停車場之汽車內，請勿放置貴重物品，本停車場僅為停車場管理，不 </li>
                    </ol>
                  </ol>
                  <p>負保管及遺失賠償責任。 <br />
                    (5). 本辦法經管理委員會審議通過後公佈實施，修訂時亦同。 </p>
                  <p>&nbsp;</p>
                  <p>　　<strong>〢、</strong>管理費收支辦法<a name="B12" id="B12"></a>　　　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <ol>
                    <li>目的 </li>
                  </ol>
                  <p>     為健全本大樓財務管理運作，依據住戶規約『管理經費』之規定，特制定本辦法。 </p>
                  <ol>
                    <li>經費來源及運用 </li>
                  </ol>
                  <p>管理經費係以大樓全體住戶之公共利益為出發點，包括下列各項： </p>
                  <ol>
                    <ol>
                      <li>收入部分 </li>
                    </ol>
                  </ol>
                  <p>      1、管理費：全體住戶按住家坪數，共同分擔之。 <br />
                    2、停車費：按使用者付費原則，用以支付地下室停車場之汽、機車停車維護費、公共電費、消防、清潔等費用。 <br />
                    3、利息收入：基金、管理費結餘等、存款之利息收入。 <br />
                    4、租金收入：大樓公有設施出租之收入。 <br />
                    5、其他部分：收取回饋金、教育活動回饋金等。 <br />
                    （二）支出部分 </p>
                  <ol>
                    <li>管理服務費：人事成本或管理公司費用。 </li>
                    <li>公用電費：公共設備之用電。 </li>
                    <li>電梯維護：第一年廠商保固，一年後由管理委員與原廠商訂定保養合約。 </li>
                    <li>垃圾清運費：環保局或民間業者清運費用。 </li>
                    <li>行政雜支：管理委員會運作及大樓所需之行政、事務費用。 </li>
                    <li>花木清潔：施肥、噴藥、換栽等費用。 </li>
                    <li>特定清潔：水塔清洗、外牆清洗、或超高作業等。 </li>
                    <li>公共設施維護費：社區內各項公有設施、設備之保養、維護之費用。 </li>
                    <li>其他設備維護費：如消防系統、抽水馬達、發電機、電燈等保養維護費。 </li>
                    <li>修繕準備金：建物或設備大規模修繕及汰換常需大筆金額；成立『修繕準備金』，日積月累可積少成多，以支付日後大額修繕金，可收儘速修復之效。 </li>
                    <li>費用計算方式 </li>
                    <ol>
                      <li>房屋清潔管理費： </li>
                    </ol>
                  </ol>
                  <p>住家清潔管理費：每月每坪<u>  70  </u>元。 <br />
                    店面清潔管理費：每月每坪<u>  35  </u>元。 </p>
                  <ol>
                    <ol>
                      <li>汽車位清潔管理費： </li>
                    </ol>
                  </ol>
                  <p>平面式汽車位；每月每位<u>200</u>元。 <br />
                    機械式汽車位；每月每位<u>400</u>元。(含電費補貼、保固期滿後之保養維護費)<br />
                    機車位收費(授權管理委員會訂定公告執行)</p>
                  <ol>
                    <li>費用收繳（季繳）。 </li>
                  </ol>
                  <p>各住戶應於每季首月內，至管理服務中心一次繳交<u>參</u>個月之管理費用，並索取收據。 </p>
                  <ol>
                    <li>費用保管及支付 </li>
                    <ol>
                      <li>本大樓各項經費之管理應於合法金融機構設立專戶處理並保管之。 </li>
                      <li>公共帳戶之取款印鑑登記，除按金融機構開戶規定外，應同列『親家愛敦閣社區管理委員會』、主任委員、監察委員及財務委員之印鑑。印章應分別保存於主任委員及財務委員、監察委員等處。 </li>
                      <li>費用支付權限如下： </li>
                    </ol>
                  </ol>
                  <p>管理服務中心或管理公司：新台幣參仟元（含）以下。 <br />
                    權責委員：新台幣壹萬元（含）以下。 <br />
                    主任委員：新台幣參萬元（含）以下。 <br />
                    管理委員會：新台幣貳拾萬元（含）以下；參拾萬元以上之大筆支出應由區分所有權人大會通過後始可動支。（已通過之”年度預算”不在此限） <br />
                    註：1、本大樓零用金訂為壹萬元。 <br />
                    2、管委會（大樓）每月撥補零用金差額至壹萬元止於管理服務中心或管理公司，以支付雜項事務費用，其零用金的使用只支付公共之消費。 <br />
                    3、零用金不敷使用時，應由管理公司提報管委會列會說明，以決定是否增加額度。 </p>
                  <ol>
                    <li>財務報表 </li>
                  </ol>
                  <p>    （一） 管理委員會必須將財務報表於每月10日前以公佈欄公佈，詳列本大樓收入、支出及結餘情形，財務報表須經財務委員、監委及主任委員簽認後始可公佈，以昭公信。 <br />
                    （二） 財務報表每月10前製作放款完畢並公告，年度報表須於區分所有權人會議前15日製作完成，並公告及寄發供住戶參閱。 </p>
                  <ol>
                    <li>附則 </li>
                  </ol>
                  <p>本辦法如有增減修改之必要，授權管理委員會研議，並公告實施。 </p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>　　<strong>〣、</strong>環境整潔管理辦法<a name="B13" id="B13"></a>　　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>一、目的 <br />
                    為提昇環境品質，維護本大樓之清潔衛生、外觀整潔及公共設施之清潔維護，特制定本辦法。 <br />
                    二、環境維護 <br />
                    （一）<u>公共設施使用注意事項 </u><br />
                    1、公共設施使用完畢，應予以歸位。若發現故障情形，應停止使用並通知管理人員處理。 <br />
                    2、洗手台及馬桶等設備，請愛惜使用；不可污染或任意投入雜物。 <br />
                    3、公設、樓梯間、牆壁等處，不得任意塗劃、刻字、噴漆或堆積物品。 <br />
                    （二）<u>空氣污染管制 </u><br />
                    1、不得於本大樓內燃燒或煙薰物品。 <br />
                    2、散發異味之物品或腐壞食物，均不得存放於本大樓。 <br />
                    3、廚房之排油煙管，應妥為裝設，勿妨礙他人。 <br />
                    4、室內公設部分全面禁煙。 <br />
                    （三）<u>其他注意事項 </u><br />
                    1、果皮、紙屑等應丟於垃圾桶內，不得隨手丟棄；煙蒂須先確定其火已熄滅，方能丟棄。 <br />
                    2、不得隨地吐痰及檳榔汁。 <br />
                    3、不得任意傾倒污水。 <br />
                    4、種植花木應注意環境維護，勿使泥土、污水污染建物及行人，並隨時保持環境衛生及美觀。 <br />
                    5、本大樓內不得飼養及攜入危險性寵物等；如飼養其他無危險性寵物者不得影響公共安全、公共安寧及環境衛生。 <br />
                    6、不得存放易燃物及爆炸物品於本大樓內。 <br />
                    三、垃圾丟棄位置 <br />
                    住戶之垃圾，應丟棄於環保回收室垃圾子車內，不得隨意丟棄其他位置。 <br />
                    四、垃圾處理方式 <br />
                    （一）<u>一般垃圾 </u><br />
                    1、住戶應將垃圾先分類後，再密封於塑膠袋內，勿使其漏出，封妥後再置於垃圾場內丟棄。 <br />
                    2、丟棄垃圾時，若垃圾掉出應將其撿拾清理乾淨。 <br />
                    （二）<u>大型垃圾 </u><br />
                    傢俱等大型垃圾，住戶應自行向所屬轄區之環保局、清潔隊或請管理服務中心協助申請清運處理，不得棄於垃圾場。 <br />
                    （三）<u>裝修垃圾 </u><br />
                    各住戶進行裝潢時，裝潢材料、木材等垃圾應由裝潢單位或住戶負責清運，不得隨意堆置，管理中心並負有監督其垃圾處理之責任。 <br />
                    （四）垃圾處理要點 <br />
                    1、廚餘之水應瀝乾後再行丟棄。 <br />
                    2、破玻璃、破陶瓷片、金屬碎片請妥為包紮，避免危害清運人員。 <br />
                    3、煙蒂、火苗應熄滅後始可丟棄。 <br />
                    （五）確實作好環保，垃圾分類後再行丟棄。 <br />
                    （六）住戶應將垃圾開口確實密合，以防惡臭或蚊蠅孳生。清潔人員配合環保單位或垃圾清運公司作業。 <br />
                    五、住戶須與清潔維護人員配合之事項 <br />
                    （一）清掃工作以不影響各住戶生活之原則進行，但於清掃時各住戶應儘量配合。 <br />
                    （二）清潔中之公共設施請暫勿使用。 <br />
                    （三）不得將私人物品堆置於公共區域。 <br />
                    （四）廣告、告示或海報禁止任意張貼。 <br />
                    （五）騎樓不得停放機車及腳踏車。 <br />
                    （六）騎樓外之車輛排列整齊，經勸阻無效後，報請拖吊大隊處理。 <br />
                    （七）各住戶應共同維護本社區清潔，切勿亂丟紙屑。 <br />
                    六、附則 <br />
                    本辦法如有增減修改之必要，授權管理委員會研議，並公告實施。 </p>
                  <p>&nbsp;</p>
                  <p>　　水療池使用管理規則<a name="B14" id="B14"></a>　　　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>壹、開放對象： <br />
                    本設施為開放式免付費設施，凡具社區區分所有權人、承租戶及其直系親屬者，皆可使用之。 <br />
                    註：一、非本社區之住戶，需由區分所有權人、承租戶、使用戶<u>親自帶領</u>，方可使用。 <br />
                    二、12歲以下兒童，需有成人陪同方可進入室內。 <br />
                    三、本場地不得攜帶寵物進入。 </p>
                  <p>貳、開放時間： <br />
                    一、每日AM08:00-PM20:00。（週一為保養日）。 <br />
                    二、管理委員會排定之社區活動時間內，本設施暫停開放。 <br />
                    參、使用注意事項： <br />
                    一、非開放時間，請勿擅自進入使用，如違反規定致發生意外者，由使用者自行負責。 <br />
                    二、有下列情事者，請勿使用本設施： <br />
                    1.患有心臟並、高血壓、皮膚病、角膜炎及傳染病者。 <br />
                    2.酗酒或高度疲勞者。 <br />
                    3.未著泳衣及戴泳帽或入池前未先行淋浴者。 <br />
                    三、使用期間請隨時保持環境整齊清潔，嚴禁吸煙及攜帶零食(茶水飲料不受此限)，以利清潔維護工作。 <br />
                    四、損壞任何設施或器材，應照價賠償。 <br />
                    五、對各項設施、設備及裝潢等，請注意維護及使用，如有損壞情形，請逕行告之社區櫃台處理。 <br />
                    六、凡違反規定者，得勒令離開，並視情節輕重，報請管委會處理，停止其使用權一至四週。 </p>
                  <p>肆、本管理使用辦法如有未盡事宜，經管理委員會會議討論通過後實施，修正亦同。 </p>
                  <p>&nbsp;</p>
                  <p>　　沙發接待交誼廳使用管理規則<a name="B15" id="B15"></a>　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>壹、開放對象： <br />
                    本設施為開放式免付費設施，凡具社區區分所有權人、承租戶及其直系親屬者，皆可使 <br />
                    用之。 <br />
                    註：一、非本社區之住戶，需由區分所有權人、承租戶、使用戶<u>親自帶領</u>，方可使用。 <br />
                    二、12歲以下兒童，需有成人陪同方可進入室內。 <br />
                    <br />
                    貳、開放時間 <br />
                    一、每日AM08:00-PM22:00<br />
                    二、管理委員會排定之社區活動時間內，本設施暫停開放。 </p>
                  <p>參、使用注意事項： <br />
                    一、請勿在場內高聲喧嘩或收聽音樂，如有干擾他人之行為，服務人員應予以制止。 <br />
                    二、服務人員得管制設施內之人數，額滿時得管制進出。 <br />
                    三、對各項設施、設備及裝潢等，請注意維護及使用，如有損壞情形，請逕行告知社區櫃台處理。 <br />
                    四、交誼廳內書報只限在室內閱讀，不得攜出。 <br />
                    五、書報不得有毀損、加註記等情事，否則需照價賠償或以書報標價等值以上之書報或同一書報交換。 <br />
                    六、室內請隨時保持環境整齊清潔，嚴禁吸煙、檳榔、酒及攜帶零食(茶水不受此限)，以利清潔維護工作。 <br />
                    七、損壞任何設施或器材，應照價賠償。 <br />
                    八、凡違反規定者，得勒令離開，並視情節輕重，報請管委會處理，停止其使用權一至四週。 </p>
                  <p>肆、本管理使用辦法如有未盡事宜，經管理委員會會議討論通過後實施，修正亦同。 </p>
                  <p>&nbsp;</p>
                  <p>　　哈瓦那 L O U N G E 使用管理規則<a name="B16" id="B16"></a>　　　　　　　<a href="#A">回最上層</a></p>
                  <ol>
                    <li>開放對象： </li>
                  </ol>
                  <p>本設施為開放式使用者付費設施，凡具社區區分所有權人、承租戶、使用戶及其直系親屬者，皆可使用之。 <br />
                    註：一、非本社區之住戶，需由區分所有權人、承租戶、使用戶<u>親自帶領</u>，方可使用。 <br />
                    二、12歲以下兒童，需有成人陪同方可進入室內。 <br />
                    三、本場地不得攜帶寵物進入。 <br />
                    貳、開放時間： <br />
                    一、每日AM08:00-PM22:00。 <br />
                    二、管理委員會排定之社區活動時間內，本設施暫停開放。 <br />
                    參、使用注意事項： <br />
                    一、請勿在場內高聲喧嘩。 <br />
                    二、服務人員得管制設施內之人數，額滿時得管制進出。 <br />
                    三、對各項設施、設備及裝潢等，請注意維護及使用，如有損壞情形，請逕行告之社區櫃台處理。 <br />
                    四、損壞任何設施或器材，應照價賠償。 <br />
                    五、凡違反規定者，得勒令離開，並視情節輕重，報請管委會處理，停止其使用權一至四週。 <br />
                    肆、本管理使用辦法如有未盡事宜，經管理委員會會議討論通過後實施，修正亦同。 </p>
                  <p>&nbsp; </p>
                  <p>&nbsp;</p>
                  <p>　　健身房使用管理規則<a name="B17" id="B17"></a>　　　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>壹、開放對象： <br />
                    本設施為開放式免付費設施，凡具社區區分所有權人、承租戶及其直系親屬者，皆可使用之。 <br />
                    註：一、非本社區之住戶，需由區分所有權人、承租戶、使用戶<u>親自帶領</u>，方可使用。 <br />
                    二、12歲以下兒童，需有成人陪同方可進入室內。 <br />
                    三、本場地不得攜帶寵物進入。 </p>
                  <p>貳、開放時間： <br />
                    一、每日AM08:00-PM22:00。 <br />
                    二、管理委員會排定之社區活動時間內，本設施暫停開放。 <br />
                    三、使用前，請先至櫃檯登記。 </p>
                  <p>參、使用注意事項： <br />
                    一、各項健身器材使用應依個人之能力調整抗力係數，以避免使用者發生危險及設備受損，使用完畢後應將抗力歸零，以延長健身器材之使用壽命。 <br />
                    二、為避免運動傷害，有身體不適或已飲酒者，請勿勉強使用，否則發生意外造成傷害時，由其個人自行負責。 <br />
                    三、進入室內請勿穿著硬質鞋類入內，以免損壞地板。 <br />
                    四、連續使用請勿超過二小時，以保障他人使用權利。(如無他人等候，可繼續使用)<br />
                    五、室內請隨時保持環境整齊清潔，嚴禁吸煙、檳榔、酒及攜帶零食(茶水不受此限)，以利清潔維護工作。 <br />
                    六、對各項設施、設備及裝潢等，請注意維護及使用，如有損壞情形，請逕行告知社區櫃台處理。 <br />
                    七、損壞任何設施或器材，應照價賠償。 <br />
                    八、凡違反規定者，得勒令離開，並視情節輕重，報請管委會處理，停止其使用權一至四週。 <br />
                    肆、本管理使用辦法如有未盡事宜，經管理委員會會議討論通過後實施，修正亦同。 </p>
                  <p>&nbsp;</p>
                  <p>　　游泳池使用管理規則<a name="B18" id="B18"></a>　　　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <ol>
                    <li>開放對象： </li>
                  </ol>
                  <p>本設施為開放式免付費設施，凡具社區區分所有權人、承租戶及其直系親屬者，皆可使用之。 <br />
                    註：一、非本社區之住戶，需由區分所有權人、承租戶、使用戶<u>親自帶領</u>，方可使用。 <br />
                    二、12歲以下兒童，需有成人陪同方可進入室內。 <br />
                    三、本場地不得攜帶寵物進入。 </p>
                  <p>貳、開放時間 <br />
                    一、週二至週日AM08:00~PM20:00（週一為保養日）。 <br />
                    二、管理中心排定之社區性活動課程時間內，本設施暫停開放。 <br />
                    三、使用前，請先至櫃檯登記。 <br />
                    四、開放時間應聘請泳池救生員。 </p>
                  <p>參、使用注意事項 <br />
                    一、非開放時間，嚴禁使用，切勿擅自進入使用，如違反規定致發生意外者，由使用者自行 <br />
                    負責。 <br />
                    二、使用前請先做熱身運動，並將身體沖洗乾淨，穿著泳衣、褲及泳帽，以維護衛生。 <br />
                    三、有下列情者，禁止使用本設施。 <br />
                    1.患有心臟病、高血壓、皮膚病、感冒、角膜炎及其他傳染病。 <br />
                    2.酗酒或高度疲勞者。 <br />
                    3.無成人陪同之12歲以下兒童。 <br />
                    4.未著泳衣及戴泳帽及入池前未先行淋浴者。 <br />
                    四、室內請隨時保持環境整齊清潔，嚴禁吸煙、檳榔、酒及攜帶零食(茶水不受此限)，以 <br />
                    利清潔維護工作。 <br />
                    五、對各項設施、設備及裝潢等，請注意維護及使用，如有損壞情形，請逕行告知櫃台處理。 <br />
                    六、損壞任何設施或器材、桌椅者，應照價賠償。 <br />
                    七、凡違反規定者，得勒令離開，並視情節輕重，報請管理中心處理，停止其使用權一至 <br />
                    四週。 </p>
                  <p>肆、本管理使用辦法如有未盡事宜，經管理委員會會議討論通過後實施，修正亦同。 </p>
                  <p>&nbsp;</p>
                  <p>　　蒸氣室、烤箱室使用管理規則<a name="B19" id="B19"></a>　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>開放對象： <br />
                    本設施為開放式免付費設施，凡具社區區分所有權人、承租戶及其直系親屬者，皆可使用之。 <br />
                    註：一、非本社區之住戶，需由區分所有權人、承租戶、使用戶<u>親自帶領</u>，方可使用。 <br />
                    二、12歲以下兒童，需有成人陪同方可進入室內。 <br />
                    三、本場地不得攜帶寵物進入。 </p>
                  <p>貳、開放時間 <br />
                    一、週二至週日AM08:00~PM20:00（週一為保養日）。 <br />
                    二、管理中心排定之社區性活動課程時間內，本設施暫停開放。 <br />
                    參、使用注意事項 <br />
                    一、使用前一小時請先向櫃檯預約登記並予繳費，以便服務人員預先開啟電源（嚴禁住戶自行啟動電源）。 <br />
                    二、使用前請先做熱身運動，並將身體沖洗乾淨，穿著泳衣、褲及泳帽，以維衛生。 <br />
                    三、嚴禁於室內閱讀報章雜誌及掛曬衣物。 <br />
                    四、嚴禁於室內使用護膚護髮產品。 <br />
                    五、請勿配帶眼鏡、項鍊、手錶等金屬飾品進入蒸氣室。 <br />
                    六、使用中身體微感不適者，請立即離開。 <br />
                    七、有心臟病、皮膚病、高血壓及懷孕者嚴禁使用。 <br />
                    八、上述各項如有違反而發生意外者，由使用者自行負責。 <br />
                    九、使用期間請隨時保持清潔，以利維護。 <br />
                    十、損壞任何設施或器材、桌椅者，應照價賠償。 <br />
                    十一、凡違反規定者，得勒令離開，並視情節輕重，報請管理中心處理，停止其使用權一至四週。 <br />
                    肆、本管理使用辦法如有未盡事宜，經管理委員會會議討論通過後實施，修正亦同。 </p>
                  <p>&nbsp;</p>
                  <p>　　親子兒童遊戲館使用管理規則<a name="B20" id="B20"></a>　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>壹、開放對象： <br />
                    本設施為開放式免付費設施，凡具社區區分所有權人、承租戶及其直系親屬者，皆可使用之。 <br />
                    註：一、非本社區之住戶，需由區分所有權人、承租戶、使用戶<u>親自帶領</u>，方可使用。 <br />
                    二、12歲以下兒童，需有成人陪同方可進入室內。 <br />
                    三、本場地不得攜帶寵物進入。 </p>
                  <p>貳、開放時間： <br />
                    一、每日AM08:00-PM22:00。 <br />
                    二、管理委員會排定之社區活動時間內，本設施暫停開放。 <br />
                    三、使用前，請先至櫃檯登記。 </p>
                  <p>參、使用注意事項： <br />
                    一、使用時需大人陪伴，注意安全，不可以做危險動作，否則發生意外造成傷害時，由其個人自行負責。 <br />
                    二、進入室內請勿穿著硬質鞋類入內，以免損壞地板。 <br />
                    三、連續使用請勿超過二小時，以保障他人使用權利。(如無他人等候，可繼續使用)<br />
                    四、室內請隨時保持環境整齊清潔，嚴禁吸煙、檳榔、酒及攜帶零食(茶水不受此限)，以利清潔維護工作。 <br />
                    五、對各項設施、設備及裝潢等，請注意維護及使用，如有損壞情形，請逕行告知社區櫃台處理。 <br />
                    六、損壞任何設施或器材，應照價賠償。 <br />
                    七、凡違反規定者，得勒令離開，並視情節輕重，報請管委會處理，停止其使用權一至四週。 </p>
                  <p>肆、本管理使用辦法如有未盡事宜，經管理委員會會議討論通過後實施，修正亦同。 </p>
                  <p>&nbsp;</p>
                  <p>　　環球視聽電影院使用管理規則<a name="B21" id="B21"></a>　　　　　　　　　<a href="#A">回最上層</a></p>
                  <ol>
                    <li>開放對象： </li>
                  </ol>
                  <p>本設施為預約使用，凡具社區區分所有權人、承租戶及其直系親屬者，皆可使用之。 <br />
                    註：一、非本社區之住戶，需由區分所有權人、承租戶、使用戶<u>親自帶領</u>，方可使用。 <br />
                    二、12歲以下兒童，需有成人陪同方可進入室內。 <br />
                    三、本場地不得攜帶寵物進入。 </p>
                  <p>貳、開放時間： <br />
                    一、每日AM08:00-PM22:00。 <br />
                    二、管理委員會排定之時間內，本設施暫停開放。 <br />
                    三、使用前，請先至櫃檯預約登記。 </p>
                  <p>參、使用注意事項： <br />
                    一、本設備之操作使用，由管理服務中心負責操作設備，住戶不得擅自操作，以免機件損壞。 <br />
                    二、室內請隨時保持環境整齊清潔，嚴禁吸煙、檳榔、酒及攜帶零食(茶水不受此限)，以利清潔維護工作。 <br />
                    三、對各項設施、設備及裝潢等，請注意維護及使用，如有損壞情形，請逕行告知社區櫃台處理。 <br />
                    四、損壞任何設施或器材，應照價賠償。 <br />
                    五、凡違反規定者，得勒令離開，並視情節輕重，報請管委會處理，停止其使用權一至四週。 </p>
                  <p>肆、本管理使用辦法如有未盡事宜，經管理委員會會議討論通過後實施，修正亦同。 </p>
                  <p>&nbsp;</p>
                  <p>　　籃球場使用管理規則<a name="B22" id="B22"></a>　　　　　　　　　　　　　<a href="#A">回最上層</a></p>
                  <p>開放對象： <br />
                    本設施為開放式免付費設施，凡具社區區分所有權人、承租戶及其直系親屬者，皆可使用之。 <br />
                    註：一、非本社區之住戶，需由區分所有權人、承租戶、使用戶<u>親自帶領</u>，方可使用。 <br />
                    二、12歲以下兒童，需有成人陪同方可進入室內。 <br />
                    三、本場地不得攜帶寵物進入。 </p>
                  <p>貳、開放時間： <br />
                    一、每日AM08:00-PM20:00。 <br />
                    二、管理委員會排定之社區活動時間內，本設施暫停開放。 <br />
                    三、使用前，請先至櫃檯登記。 </p>
                  <p>參、使用注意事項： <br />
                    一、使用籃球設施人數超出兩組以上時，請依先後順序輪流使用。 <br />
                    二、進入籃球場請依規定穿著運動服裝及運動鞋，未依規定穿著者，一律不得使用 <br />
                    三、本籃球場禁止攜帶寵物入內；未滿七歲之兒童禁止單獨進入，需由大人陪同方 <br />
                    可進入。 <br />
                    四、籃球場內請保持清潔，禁止在內吸煙、嚼檳榔及攜帶食物入內食用。 <br />
                    五、籃球場內所有器材請愛惜使用，住戶一律不得將器材攜出，若有不當使用或蓄 <br />
                    意破壞而造成損壞者，得依市價照價賠償。 <br />
                    六、為避免運動傷害，有身體不適或已飲酒者，請勿勉強使用，否則發生意外造成 <br />
                    傷害時，由其個人自行負責。 <br />
                    七、凡違反規定者，得勒令離開，並視情節輕重，報請管理中心處理，停止其使用 <br />
                    權一至四週。 <br />
                    肆、本管理使用辦法如有未盡事宜，經管理委員會會議討論通過後實施，修正亦同。 </p></th>
              </tr>
            </table></td>
          </tr>
        </table>
          <table border="0" cellpadding="0" cellspacing="0" id="pic3_left">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table border="0" cellpadding="0" cellspacing="0" id="pic4">
      <tr>
        <td align="center"><span style="background-position: center; background-image: url(img/third/dn_bar.gif); font-size: 12px; color: #FFF; font-family: '微軟正黑體';">版權所有◎2010 超媒體管家企業有限公司</span></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
