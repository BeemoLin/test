<?php
#	BuildNav for Dreamweaver MX v0.2
#              10-02-2002
#	Alessandro Crugnola [TMM]
#	sephiroth: alessandro@sephiroth.it
#	http://www.sephiroth.it
#	
#	Function for navigation build ::
function buildNavigation($pageNum_Recordset1,$totalPages_Recordset1,$prev_Recordset1,$next_Recordset1,$separator=" | ",$max_links=10, $show_page=true)
{
                GLOBAL $maxRows_RecMoney,$totalRows_RecMoney;
	$pagesArray = ""; $firstArray = ""; $lastArray = "";
	if($max_links<2)$max_links=2;
	if($pageNum_Recordset1<=$totalPages_Recordset1 && $pageNum_Recordset1>=0)
	{
		if ($pageNum_Recordset1 > ceil($max_links/2))
		{
			$fgp = $pageNum_Recordset1 - ceil($max_links/2) > 0 ? $pageNum_Recordset1 - ceil($max_links/2) : 1;
			$egp = $pageNum_Recordset1 + ceil($max_links/2);
			if ($egp >= $totalPages_Recordset1)
			{
				$egp = $totalPages_Recordset1+1;
				$fgp = $totalPages_Recordset1 - ($max_links-1) > 0 ? $totalPages_Recordset1  - ($max_links-1) : 1;
			}
		}
		else {
			$fgp = 0;
			$egp = $totalPages_Recordset1 >= $max_links ? $max_links : $totalPages_Recordset1+1;
		}
		if($totalPages_Recordset1 >= 1) {
			#	------------------------
			#	Searching for $_GET vars
			#	------------------------
			$_get_vars = '';			
			if(!empty($_GET) || !empty($HTTP_GET_VARS)){
				$_GET = empty($_GET) ? $HTTP_GET_VARS : $_GET;
				foreach ($_GET as $_get_name => $_get_value) {
					if ($_get_name != "pageNum_RecMoney") {
						$_get_vars .= "&$_get_name=$_get_value";
					}
				}
			}
			$successivo = $pageNum_Recordset1+1;
			$precedente = $pageNum_Recordset1-1;
			$firstArray = ($pageNum_Recordset1 > 0) ? "<a href=\"$_SERVER[PHP_SELF]?pageNum_RecMoney=$precedente$_get_vars\">$prev_Recordset1</a>" :  "$prev_Recordset1";
			# ----------------------
			# page numbers
			# ----------------------
			for($a = $fgp+1; $a <= $egp; $a++){
				$theNext = $a-1;
				if($show_page)
				{
					$textLink = $a;
				} else {
					$min_l = (($a-1)*$maxRows_RecMoney) + 1;
					$max_l = ($a*$maxRows_RecMoney >= $totalRows_RecMoney) ? $totalRows_RecMoney : ($a*$maxRows_RecMoney);
					$textLink = "$min_l - $max_l";
				}
				$_ss_k = floor($theNext/26);
				if ($theNext != $pageNum_Recordset1)
				{
					$pagesArray .= "<a href=\"$_SERVER[PHP_SELF]?pageNum_RecMoney=$theNext$_get_vars\">";
					$pagesArray .= "$textLink</a>" . ($theNext < $egp-1 ? $separator : "");
				} else {
					$pagesArray .= "$textLink"  . ($theNext < $egp-1 ? $separator : "");
				}
			}
			$theNext = $pageNum_Recordset1+1;
			$offset_end = $totalPages_Recordset1;
			$lastArray = ($pageNum_Recordset1 < $totalPages_Recordset1) ? "<a href=\"$_SERVER[PHP_SELF]?pageNum_RecMoney=$successivo$_get_vars\">$next_Recordset1</a>" : "$next_Recordset1";
		}
	}
	return array($firstArray,$pagesArray,$lastArray);
}
?>
<?php require_once('Connections/connSQL.php'); ?>

<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **

$logoutAction = 'logout.php';

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "admin,member";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_RecUser = 7;
$pageNum_RecUser = 0;
if (isset($_GET['pageNum_RecUser'])) {
  $pageNum_RecUser = $_GET['pageNum_RecUser'];
}
$startRow_RecUser = $pageNum_RecUser * $maxRows_RecUser;

$colname_RecUser = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_RecUser = $_SESSION['MM_Username'];
}
mysql_select_db($database_connSQL, $connSQL);
$query_RecUser = sprintf("SELECT m_id, m_name, m_nick, m_username FROM memberdata WHERE m_username = %s", GetSQLValueString($colname_RecUser, "text"));
$query_limit_RecUser = sprintf("%s LIMIT %d, %d", $query_RecUser, $startRow_RecUser, $maxRows_RecUser);
$RecUser = mysql_query($query_limit_RecUser, $connSQL) or die(mysql_error());
$row_RecUser = mysql_fetch_assoc($RecUser);

if (isset($_GET['totalRows_RecUser'])) {
  $totalRows_RecUser = $_GET['totalRows_RecUser'];
} else {
  $all_RecUser = mysql_query($query_RecUser);
  $totalRows_RecUser = mysql_num_rows($all_RecUser);
}
$totalPages_RecUser = ceil($totalRows_RecUser/$maxRows_RecUser)-1;

$maxRows_RecMoney = 10;
$pageNum_RecMoney = 0;
if (isset($_GET['pageNum_RecMoney'])) {
  $pageNum_RecMoney = $_GET['pageNum_RecMoney'];
}
$startRow_RecMoney = $pageNum_RecMoney * $maxRows_RecMoney;

mysql_select_db($database_connSQL, $connSQL);
$query_RecMoney = "SELECT * FROM money_album ORDER BY album_date DESC";
$query_limit_RecMoney = sprintf("%s LIMIT %d, %d", $query_RecMoney, $startRow_RecMoney, $maxRows_RecMoney);
$RecMoney = mysql_query($query_limit_RecMoney, $connSQL) or die(mysql_error());
$row_RecMoney = mysql_fetch_assoc($RecMoney);

if (isset($_GET['totalRows_RecMoney'])) {
  $totalRows_RecMoney = $_GET['totalRows_RecMoney'];
} else {
  $all_RecMoney = mysql_query($query_RecMoney);
  $totalRows_RecMoney = mysql_num_rows($all_RecMoney);
}
$totalPages_RecMoney = ceil($totalRows_RecMoney/$maxRows_RecMoney)-1;

$queryString_RecUser = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_RecUser") == false && 
        stristr($param, "totalRows_RecUser") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_RecUser = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_RecUser = sprintf("&totalRows_RecUser=%d%s", $totalRows_RecUser, $queryString_RecUser);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>財務報表</title>
<style type="text/css">
<!--
body {
	background-image: url();
	background-repeat: no-repeat;
	margin-left: 0px;
	margin-top: 0px;
	background-color: #000;
	font-family: "微軟正黑體";
	color: #FFF;
}
.all {
	background-image: url(img/third/backgrondreal.jpg);
}
.white {
	color: #FFF;
	font-family: "微軟正黑體";
}
-->
</style>
<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
//-->
</script>
<link href="CSS/link.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.a {	font-family: "微軟正黑體";
}
.q {	height: 150px;
	width: 100px;
	font-size: 12px;
	float: left;
	font-family: "微軟正黑體";
}
.all tr th table tr td table tr th {
	color: #FFF;
}
.all tr th table tr td table tr th {
	font-family: "微軟正黑體";
}
.white1 {color: #FFF;
	font-family: "微軟正黑體";
}
#a1 {	height: 95px;
	width: 10px;
	float: left;
}
#a10 {	height: 95px;
	width: 40px;
	float: right;
}
#a2 {	height: 95px;
	width: 90px;
	float: left;
}
#a3 {	height: 95px;
	width: 90px;
	float: left;
}
#a4 {	height: 95px;
	width: 90px;
	float: left;
}
#a5 {	height: 95px;
	width: 90px;
	float: left;
}
#a6 {	height: 95px;
	width: 90px;
	float: left;
}
#a7 {	height: 95px;
	width: 90px;
	float: left;
}
#a8 {	height: 95px;
	width: 90px;
	float: left;
}
#a9 {	height: 95px;
	width: 90px;
	float: left;
}
#allpic {
	background-image: url(img/beforepic/backgrondreal.jpg);
	height: 580px;
	width: 770px;
	background-repeat: no-repeat;
}
#apDiv1 {	position:relative;
	width:32px;
	height:73px;
	z-index:1;
	left: 0px;
	top: 10px;
}
.color {
	color: #000;
	font-family: "微軟正黑體";
	text-decoration: blink;
}
#apDiv2 {	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
	left: -250px;
	top: 77px;
	visibility: hidden;
}
#pic1 {	height: 75px;
	width: 770px;
}
#pic2 {	height: 100px;
	width: 770px;
}
#pic3 {
	height: 390px;
	width: 770px;
	background-repeat: no-repeat;
	background-position: left;
}
#pic3_left {	float: left;
	height: 390px;
	width: 10px;
}
#pic3_right {
	float: left;
	height: 390px;
	width: 750px;
	background-image: url(img/img/gray_BG.jpg);
}
#pic4 {	background-image: url(img/beforepic/dn_bar.gif);
	height: 20px;
	width: 770px;
}
#title {	float: left;
	height: 65px;
	width: 175px;
	background-image: url(img/third/LOGO.gif);
	background-repeat: no-repeat;
	background-position: right center;
}
#title2 {	float: left;
	height: 65px;
	width: 180px;
	background-image: url(img/beforepic/1.gif);
	background-repeat: no-repeat;
	background-position: right center;
}
#title3 {	float: right;
	height: 75px;
	width: 300px;
}
#title3_left {	float: left;
	height: 75px;
	width: 190px;
}
#title3_left_down {	height: 37px;
	width: 190px;
}
#title3_left_up {	height: 37px;
	width: 190px;
}
#title3_right {	float: right;
	height: 75px;
	width: 110px;
}
#title3_right_down {	height: 37px;
	width: 110px;
}
#title3_right_up {	height: 37px;
	width: 110px;
}
-->
</style>
</head>

<body onload="MM_preloadImages('img/third/btn_ bulletin_dn.gif','img/third/btn_opinion_dn.gif','img/third/btn_equipment_dn.gif','img/third/btn_share_dn.gif','img/third/btn_food_dn.gif','img/third/btn_photo_dn.gif','img/third/btn_mony_dn.gif','img/third/btn_fix_dn.gif','img/third/arrow_up(3).gif','img/third/btn_list_dn.gif','img/third/btn_rule_dn.gif','img/third/btn_info_dn.gif')">
<table border="0" align="center" cellpadding="0" cellspacing="0" id="allpic">
  <tr>
    <td height="75"><table border="0" cellpadding="0" cellspacing="0" id="pic1">
      <tr>
        <td><table border="0" cellpadding="0" cellspacing="0" id="title3">
          <tr>
            <td><table border="0" cellpadding="0" cellspacing="0" id="title3_left">
              <tr>
                <td><table border="0" cellpadding="0" cellspacing="0" id="title3_left_up">
                  <tr>
                    <td><img src="img/third/green_yes.gif" alt="" width="30" height="30" align="absbottom" /><span class="white1"><span class="white"><?php echo $row_RecUser['m_username']; ?></span><img src="img/life2/HI.gif" alt="" width="50" height="30" align="absbottom" /></span></td>
                  </tr>
                </table>
                  <table border="0" cellpadding="0" cellspacing="0" id="title3_left_down">
                    <tr>
                      <td><img src="img/third/in.gif" alt="" width="30" height="30" align="absbottom" /><a href="<?php echo $logoutAction ?>"><img src="img/life2/guest_out.gif" alt="" width="80" height="30" border="0" align="absbottom" /></a></td>
                    </tr>
                  </table></td>
              </tr>
            </table>
              <table border="0" cellpadding="0" cellspacing="0" id="title3_right">
                <tr>
                  <td><table border="0" cellpadding="0" cellspacing="0" id="title3_right_up">
                    <tr>
                      <td><a href="indexre.php?<?php echo "m_username=".urlencode($row_RecUser['m_username']) ?>"><img src="img/BTN/re.gif" alt="" width="110" height="30" border="0" /></a></td>
                    </tr>
                  </table>
                    <table border="0" cellpadding="0" cellspacing="0" id="title3_right_down">
                      <tr>
                        <td><img src="img/third/home.gif" alt="" width="30" height="30" align="absbottom" /><a href="index2.php"><img src="img/life2/FP.gif" alt="" width="50" height="30" border="0" align="absbottom" /></a></td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
          </tr>
        </table>
          <table border="0" cellpadding="0" cellspacing="0" id="title">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="title2">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="100"><table border="0" cellpadding="0" cellspacing="0" id="pic2">
      <tr>
        <td><table border="0" cellpadding="0" cellspacing="0" id="a10">
          <tr>
            <td><div id="apDiv1">
              <div id="apDiv2">
                <table width="290" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <th width="5" align="left" valign="top" bgcolor="#000000" scope="row"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side.gif" alt="a" width="3" height="95" vspace="0" border="0" align="left" /></a></th>
                    <td height="95" bgcolor="#000000"><a href="QandA.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image15','','img/third/btn_list_dn.gif',1)"><img src="img/third/btn_list_up.gif" alt="a" name="Image15" width="90" height="90" border="0" id="Image15" /></a></td>
                    <td width="5" bgcolor="#000000">&nbsp;</td>
                    <td bgcolor="#000000"><a href="rule.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image17','','img/third/btn_rule_dn.gif',1)"><img src="img/third/btn_rule_up.gif" alt="a" name="Image17" width="90" height="90" border="0" id="Image17" /></a></td>
                    <td width="5" bgcolor="#000000">&nbsp;</td>
                    <td bgcolor="#000000"><a href="info.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image16','','img/third/btn_info_dn.gif',1)"><img src="img/third/btn_info_up.gif" alt="a" name="Image16" width="90" height="90" border="0" id="Image16" /></a></td>
                    <td width="5" bgcolor="#000000"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side.gif" alt="a" width="3" height="95" vspace="0" border="0" align="right" /></a></td>
                  </tr>
                  <tr>
                    <th height="3" colspan="7" align="left" valign="top" scope="row"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side2.gif" alt="a" width="290" height="3" border="0" /></a></th>
                  </tr>
                  <tr>
                    <th height="9" colspan="7" align="center" valign="top" scope="row">&nbsp;</th>
                  </tr>
                </table>
              </div>
              <a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image24','','img/third/arrow_up(3).gif',1)"><img src="img/third/arrow_dn(3).gif" alt="" name="Image24" width="30" height="70" border="0" id="Image24" onmousedown="MM_showHideLayers('apDiv2','','show')" /></a></div></td>
          </tr>
        </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a1">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a2">
            <tr>
              <td><a href="announcement.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image1','','img/third/btn_ bulletin_dn.gif',1);MM_showHideLayers('apDiv2','','hide')"><img src="img/third/btn_ bulletin_up.gif" alt="" name="Image1" width="87" height="87" border="0" id="Image1" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a3">
            <tr>
              <td><a href="opinion.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image101','','img/third/btn_opinion_dn.gif',1);MM_showHideLayers('apDiv2','','hide')"><img src="img/third/btn_opinion_up.gif" alt="" name="Image101" width="87" height="87" border="0" id="Image101" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a4">
            <tr>
              <td><a href="order.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image111','','img/third/btn_equipment_dn.gif',1);MM_showHideLayers('apDiv2','','hide')"><img src="img/third/btn_equipment_up.gif" alt="" name="Image111" width="87" height="87" border="0" id="Image111" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a5">
            <tr>
              <td><a href="share.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image121','','img/third/btn_share_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_share_up.gif" alt="" name="Image121" width="87" height="87" border="0" id="Image121" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a6">
            <tr>
              <td><a href="life.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image131','','img/third/btn_food_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_food_up.gif" alt="" name="Image131" width="87" height="87" border="0" id="Image131" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a7">
            <tr>
              <td><a href="photos.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image141','','img/third/btn_photo_dn.gif',1);MM_showHideLayers('apDiv2','','hide')"><img src="img/third/btn_photo_up.gif" alt="" name="Image141" width="87" height="87" border="0" id="Image141" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a8">
            <tr>
              <td><a href="money.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image151','','img/third/btn_mony_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_mony_dn.gif" alt="" name="Image151" width="87" height="87" border="0" id="Image151" /></a></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0" id="a9">
            <tr>
              <td><a href="online.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image161','','img/third/btn_fix_dn.gif',1)"><img src="img/third/btn_fix_up.gif" alt="" name="Image161" width="87" height="87" border="0" id="Image161" /></a></td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="390"><table border="0" cellpadding="0" cellspacing="0" id="pic3_right">
            <tr>
              <td align="center" valign="middle">
              <?php

                $link = mysql_connect("61.221.56.138", "chingjia", "chingjia2011") or die("Could not connect : " . mysql_error());
                mysql_select_db("chingjia") or die("Could not select database");
				mysql_query("SET NAMES 'utf8'");
				mysql_query("SET CHARACTER_SET_CLIENT=utf8;"); 
				mysql_query("SET CHARACTER_SET_RESULTS=utf8;");
				?>
                <?php

$sql = "select * from GN_PAY0_LIST";
$result = mysql_query($sql);
while($row=mysql_fetch_array($result))
{
	?>
<br />
              <table width="300" border="1" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="161" class="color">社區編號</td>
                  <td width="133"><?php echo $row["C_CODE"]; ?></td>
                </tr>
                <tr>
                  <td class="color">繳費期數</td>
                  <td><?php echo $row["PAY_NUM"]; ?></td>
                </tr>
                <tr>
                  <td class="color">住戶編號</td>
                  <td><?php echo $row["D_NUMBER"]; ?></td>
                </tr>
                <tr>
                  <td class="color">幾段收費</td>
                  <td><?php echo $row["PAY_AE_HOW"]; ?></td>
                </tr>
                <tr>
                  <td class="color">本期繳費金額</td>
                  <td><?php echo $row["ADD_MONEY1"]; ?></td>
                </tr>
                <tr>
                  <td class="color">額外折扣</td>
                  <td><?php echo $row["OTHER_DISCOUNT"]; ?></td>
                </tr>
                <tr>
                  <td class="color">收據編號</td>
                  <td><?php echo $row["PROVE_NUM"]; ?></td>
                </tr>
                <tr>
                  <td class="color">繳費日</td>
                  <td><?php echo $row["REV_DATE"]; ?></td>
                </tr>
                <tr>
                  <td class="color">作廢否</td>
                  <td><?php echo $row["CANCEL_FAG"]; ?></td>
                </tr>
              </table>
              <br />
              <?php } ?></td>
            </tr>
          </table></td>
  </tr>
  <tr>
    <td><table border="0" cellpadding="0" cellspacing="0" id="pic4">
      <tr>
        <td align="center">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
