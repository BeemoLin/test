<?php require_once('Connections/connSQL.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **

$logoutAction = 'logout.php';

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "admin,member";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_RecAlbum = "-1";
if (isset($_GET['album_id'])) {
  $colname_RecAlbum = $_GET['album_id'];
}
mysql_select_db($database_connSQL, $connSQL);
$query_RecAlbum = sprintf("SELECT * FROM album WHERE album_id = %s", GetSQLValueString($colname_RecAlbum, "int"));
$RecAlbum = mysql_query($query_RecAlbum, $connSQL) or die(mysql_error());
$row_RecAlbum = mysql_fetch_assoc($RecAlbum);
$totalRows_RecAlbum = mysql_num_rows($RecAlbum);

$colname_RecPhoto = "-1";
if (isset($_GET['ap_id'])) {
  $colname_RecPhoto = $_GET['ap_id'];
}
mysql_select_db($database_connSQL, $connSQL);
$query_RecPhoto = sprintf("SELECT * FROM albumphoto WHERE ap_id = %s", GetSQLValueString($colname_RecPhoto, "int"));
$RecPhoto = mysql_query($query_RecPhoto, $connSQL) or die(mysql_error());
$row_RecPhoto = mysql_fetch_assoc($RecPhoto);
$totalRows_RecPhoto = mysql_num_rows($RecPhoto);

$colname_RecUser = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_RecUser = $_SESSION['MM_Username'];
}
mysql_select_db($database_connSQL, $connSQL);
$query_RecUser = sprintf("SELECT m_id, m_name, m_nick, m_username FROM memberdata WHERE m_username = %s", GetSQLValueString($colname_RecUser, "text"));
$RecUser = mysql_query($query_RecUser, $connSQL) or die(mysql_error());
$row_RecUser = mysql_fetch_assoc($RecUser);
$totalRows_RecUser = mysql_num_rows($RecUser);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>社區剪影</title>
<style type="text/css">
<!--
body {
	background-image: url();
	background-repeat: no-repeat;
	margin-left: 0px;
	margin-top: 0px;
	background-color: #000;
}
.all {
	background-image: url(img/third/backgrondreal.jpg);
}
.white {
	color: #FFF;
	font-size: 24;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
//-->
</script>
<link href="CSS/link.css" rel="stylesheet" type="text/css" />
<link href="CSS/word.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.white1 {	color: #FFF;
	font-family: "微軟正黑體";
}
#apDiv1 {
	position:relative;
	width:32px;
	height:73px;
	z-index:1;
	left: 0px;
	top: 0px;
}
#apDiv2 {
	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
	left: -258px;
	top: 88px;
	visibility: hidden;
}
-->
</style>
</head>

<body onload="MM_preloadImages('img/third/btn_ bulletin_dn.gif','img/third/btn_opinion_dn.gif','img/third/btn_equipment_dn.gif','img/third/btn_share_dn.gif','img/third/btn_food_dn.gif','img/third/btn_photo_dn.gif','img/third/btn_mony_dn.gif','img/third/btn_fix_dn.gif','img/third/arrow_up(3).gif','img/third/btn_list_dn.gif','img/third/btn_rule_dn.gif','img/third/btn_info_dn.gif')">
<table width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="all">
  <tr>
    <th height="77" scope="row"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="26%" height="74" scope="row"><img src="img/third/LOGO.gif" width="175" height="55" /></th>
        <td width="47%"><table border="0" align="left" cellpadding="10" cellspacing="0">
          <tr>
            <td><img src="img/top_toplogo.jpg" alt="" width="175" height="55" border="0" /></td>
          </tr>
        </table></td>
        <td width="27%"><table width="270" border="0" align="right" cellpadding="0" cellspacing="0">
          <tr>
            <th width="180" height="32" align="left" scope="row"><img src="img/third/green_yes.gif" width="30" height="30" align="absbottom" /><span class="white"><span class="white1"><?php echo $row_RecUser['m_username']; ?></span><img src="img/life2/HI.gif" width="50" height="30" align="absbottom" /></span></th>
            <td width="110">&nbsp;</td>
          </tr>
          <tr>
            <th width="180" height="34" align="left" scope="row"><img src="img/third/in.gif" width="30" height="30" align="absbottom" /><a href="<?php echo $logoutAction ?>"></a><a href="<?php echo $logoutAction ?>"><img src="img/life2/guest_out.gif" width="80" height="30" border="0" align="absbottom" /></a></th>
            <td align="right"><img src="img/third/home.gif" width="30" height="30" align="absbottom" /><a href="index2.php"><img src="img/life2/FP.gif" width="50" height="30" border="0" align="absbottom" /></a></td>
          </tr>
        </table></td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th height="103" scope="row"><table width="800" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="10" height="91" scope="row">&nbsp;</th>
        <td width="95" align="center"><a href="announcement.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image2','','img/third/btn_ bulletin_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_ bulletin_up.gif" name="Image2" width="90" height="90" border="0" id="Image2" /></a></td>
        <td width="95" align="center" valign="middle"><a href="opinion.php" onmouseover="MM_swapImage('Image3','','img/third/btn_opinion_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')" onmouseout="MM_swapImgRestore()"><img src="img/third/btn_opinion_up.gif" name="Image3" width="90" height="90" border="0" id="Image3" /></a></td>
        <td width="95" align="center"><a href="order.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image4','','img/third/btn_equipment_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_equipment_up.gif" name="Image4" width="90" height="90" border="0" id="Image4" /></a></td>
        <td width="95" align="center"><a href="share.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image5','','img/third/btn_share_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_share_up.gif" name="Image5" width="90" height="90" border="0" id="Image5" /></a></td>
        <td width="95" align="center"><a href="life.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image6','','img/third/btn_food_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_food_up.gif" name="Image6" width="90" height="90" border="0" id="Image6" /></a></td>
        <td width="95" align="center"><a href="photos.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image7','','img/third/btn_photo_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_photo_dn.gif" name="Image7" width="90" height="90" border="0" id="Image7" /></a></td>
        <td width="95" align="center"><a href="money.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image8','','img/third/btn_mony_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_mony_up.gif" name="Image8" width="90" height="90" border="0" id="Image8" /></a></td>
        <td width="95" align="center"><a href="online.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image9','','img/third/btn_fix_dn.gif',1)"><img src="img/third/btn_fix_up.gif" name="Image9" width="90" height="90" border="0" id="Image9" /></a></td>
        <td width="30"><p><div id="apDiv1">
  <div id="apDiv2">
    <table width="290" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="5" align="left" valign="top" bgcolor="#000000" scope="row"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side.gif" alt="a" width="3" height="95" vspace="0" border="0" align="left" /></a></th>
        <td height="95" bgcolor="#000000"><a href="QandA.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image15','','img/third/btn_list_dn.gif',1)"><img src="img/third/btn_list_up.gif" alt="a" name="Image15" width="90" height="90" border="0" id="Image15" /></a></td>
        <td width="5" bgcolor="#000000">&nbsp;</td>
        <td bgcolor="#000000"><a href="rule.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image17','','img/third/btn_rule_dn.gif',1)"><img src="img/third/btn_rule_up.gif" alt="a" name="Image17" width="90" height="90" border="0" id="Image17" /></a></td>
        <td width="5" bgcolor="#000000">&nbsp;</td>
        <td bgcolor="#000000"><a href="info.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image16','','img/third/btn_info_dn.gif',1)"><img src="img/third/btn_info_up.gif" alt="a" name="Image16" width="90" height="90" border="0" id="Image16" /></a></td>
        <td width="5" bgcolor="#000000"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side.gif" alt="a" width="3" height="95" vspace="0" border="0" align="right" /></a></td>
      </tr>
      <tr>
        <th height="3" colspan="7" align="left" valign="top" scope="row"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side2.gif" alt="a" width="290" height="3" border="0" /></a></th>
      </tr>
      <tr>
        <th height="9" colspan="7" align="center" valign="top" scope="row">&nbsp;</th>
      </tr>
    </table>
  </div>
<a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image23','','img/third/arrow_up(3).gif',0)"><img src="img/third/arrow_dn(3).gif" name="Image23" width="30" height="70" border="0" id="Image23" onmousedown="MM_showHideLayers('apDiv2','','show')" /></a></div></p></td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th height="389" valign="middle" style="height: 389px; background-image: url(img/third/picture.gif); color: #FFF; font-family: '微軟正黑體';" scope="row"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="3%" height="369" scope="row">&nbsp;</th>
        <td width="97%" valign="top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="365" align="center"><div>
              <div><img src="backstage/photos/<?php echo $row_RecPhoto['ap_picurl']; ?>" alt="" height="300" /></div>
            </div>
              <div><?php echo $row_RecPhoto['ap_subject']; ?>
                <table width="10%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><div>
                      <div class="actionDiv"><a href="javascript:window.history.back();">回上一頁</a></div>
                    </div></td>
                  </tr>
                </table>
              </div>
              <div></div>
              <div></div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <th scope="row">&nbsp;</th>
        <td>&nbsp;</td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th height="29" style="background-position: center; background-image: url(img/third/dn_bar.gif);" scope="row"><span style="background-position: center; background-image: url(img/third/dn_bar.gif); font-size: 12px; color: #FFF; font-family: '微軟正黑體';">版權所有◎2010 超媒體管家企業有限公司</span></th>
  </tr>
</table>

</body>
</html>
