<?php require_once('Connections/connSQL.php'); ?>
<?php require_once('Connections/connSQL.php'); ?>
<?php require_once('Connections/connSQL.php'); ?>
<?php require_once('Connections/connSQL.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **

$logoutAction = 'logout.php';

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "admin,member";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_GET['order_id'])) && ($_GET['order_id'] != "") && (isset($_GET['dele']))) {
  $deleteSQL = sprintf("DELETE FROM `order` WHERE order_id=%s",
                       GetSQLValueString($_GET['order_id'], "int"));

  mysql_select_db($database_connSQL, $connSQL);
  $Result1 = mysql_query($deleteSQL, $connSQL) or die(mysql_error());

  $deleteGoTo = "ordermovie.php";
  header(sprintf("Location: %s", $deleteGoTo));
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO `order` (`year`, `month`, `day`, order_name, order_time, o_time) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['year'], "int"),
                       GetSQLValueString($_POST['month'], "int"),
                       GetSQLValueString($_POST['day'], "text"),
                       GetSQLValueString($_POST['order_name'], "text"),
                       GetSQLValueString($_POST['order_time'], "text"),
                       GetSQLValueString($_POST['o_time'], "int"));

  mysql_select_db($database_connSQL, $connSQL);
  $Result1 = mysql_query($insertSQL, $connSQL) or die(mysql_error());

  $insertGoTo = "order_reday_movie.php";
  header(sprintf("Location: %s", $insertGoTo));
}

if ((isset($_GET['order_id'])) && ($_GET['order_id'] != "") && (isset($_GET['dele']))) {
  $deleteSQL = sprintf("DELETE FROM ``order`` WHERE order_id=%s",
                       GetSQLValueString($_GET['order_id'], "int"));

  mysql_select_db($database_connSQL, $connSQL);
  $Result1 = mysql_query($deleteSQL, $connSQL) or die(mysql_error());

  $deleteGoTo = "ordermovie.php";
    if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }

  header(sprintf("Location: %s", $deleteGoTo));
}

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_RecUser = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_RecUser = $_SESSION['MM_Username'];
}
mysql_select_db($database_connSQL, $connSQL);
$query_RecUser = sprintf("SELECT m_id, m_name, m_nick, m_username FROM memberdata WHERE m_username = %s", GetSQLValueString($colname_RecUser, "text"));
$RecUser = mysql_query($query_RecUser, $connSQL) or die(mysql_error());
$row_RecUser = mysql_fetch_assoc($RecUser);
$totalRows_RecUser = mysql_num_rows($RecUser);





?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>公設預約</title>
<style type="text/css">
<!--
body {
	background-image: url();
	background-repeat: no-repeat;
	margin-left: 0px;
	margin-top: 0px;
	background-color: #000;
}
.all {
	background-image: url(img/third/backgrondreal.jpg);
	font-family: "微軟正黑體";
}
.white {
	color: #FFF;
	font-family: "微軟正黑體";
}
.all tr th table tr th {
}
.red {
	color: #F00;
}
.green {
	color: #0F0;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
function MM_popupMsg(msg) { //v1.0
  alert(msg);
}
function tfm_confirmLink(message) { //v1.0
	if(message == "") message = "Ok to continue?";	
	document.MM_returnValue = confirm(message);
}
//-->
</script>
<link href="CSS/link.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
#apDiv1 {
	position:relative;
	width:32px;
	height:73px;
	z-index:1;
	left: 0px;
	top: 0px;
}
#apDiv2 {
	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
	left: -246px;
	top: 88px;
	visibility: hidden;
}
#apDiv3 {
	position:absolute;
	width:200px;
	height:140px;
	z-index:2;
	left: 306px;
	top: 271px;
	visibility: hidden;
}
#apDiv4 {
	position:absolute;
	width:250px;
	height:167px;
	z-index:2;
	left: 157px;
	top: 310px;
	visibility: hidden;
}
#apDiv5 {
	position:absolute;
	width:200px;
	height:115px;
	z-index:3;
	visibility: hidden;
}
.ggg {
	font-size: 20px;
	font-family: "微軟正黑體";
}
.qwertyu {
	font-family: "微軟正黑體";
}
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body onload="MM_preloadImages('img/third/btn_ bulletin_dn.gif','img/third/btn_opinion_dn.gif','img/third/btn_equipment_dn.gif','img/third/btn_share_dn.gif','img/third/btn_food_dn.gif','img/third/btn_photo_dn.gif','img/third/btn_mony_dn.gif','img/third/btn_fix_dn.gif','img/third/rule_dn.gif','img/third/choose_dn.gif','img/third/arrow_up(3).gif')">
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" class="all">
  <tr>
    <th height="77" scope="row"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="23%" height="74" scope="row">&nbsp;</th>
        <td width="43%">&nbsp;</td>
        <td width="34%"><table width="270" border="0" align="right" cellpadding="0" cellspacing="0">
          <tr>
            <th width="69%" height="32" align="left" scope="row"><img src="img/third/green_yes.gif" width="30" height="30" align="absbottom" /><span class="white"><?php echo $row_RecUser['m_username']; ?><img src="img/life2/HI.gif" width="50" height="30" align="absbottom" /></span></th>
            <td width="110"><a href="indexre.php?<?php echo "m_username=".urlencode($row_RecUser['m_username']) ?>"><img src="img/BTN/re.gif" width="110" height="30" border="0" /></a></td>
          </tr>
          <tr>
            <th width="180" height="34" align="left" scope="row"><img src="img/third/in.gif" width="30" height="30" align="absbottom" /><a href="<?php echo $logoutAction ?>"><img src="img/life2/guest_out.gif" width="80" height="30" border="0" align="absbottom" /></a></th>
            <td align="right"><img src="img/third/home.gif" width="30" height="30" align="absbottom" /><a href="index2.php"><img src="img/life2/FP.gif" width="50" height="30" border="0" align="absbottom" /></a></td>
          </tr>
        </table></td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th height="103" scope="row"><table width="770" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="10" height="91" scope="row">&nbsp;</th>
        <td width="95" align="center"><a href="announcement.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image2','','img/third/btn_ bulletin_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_ bulletin_up.gif" name="Image2" width="90" height="90" border="0" id="Image2" /></a></td>
        <td width="95" align="center" valign="middle"><a href="opinion.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image3','','img/third/btn_opinion_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_opinion_up.gif" name="Image3" width="90" height="90" border="0" id="Image3" /></a></td>
        <td width="95" align="center"><a href="order.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image4','','img/third/btn_equipment_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_equipment_dn.gif" name="Image4" width="90" height="90" border="0" id="Image4" /></a></td>
        <td width="95" align="center"><a href="share.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image5','','img/third/btn_share_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_share_up.gif" name="Image5" width="90" height="90" border="0" id="Image5" /></a></td>
        <td width="95" align="center"><a href="life.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image6','','img/third/btn_food_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_food_up.gif" name="Image6" width="90" height="90" border="0" id="Image6" /></a></td>
        <td width="95" align="center"><a href="photos.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image7','','img/third/btn_photo_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_photo_up.gif" name="Image7" width="90" height="90" border="0" id="Image7" /></a></td>
        <td width="95" align="center"><a href="money.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image8','','img/third/btn_mony_dn.gif',1);MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/btn_mony_up.gif" name="Image8" width="90" height="90" border="0" id="Image8" /></a></td>
        <td width="95" align="center"><a href="online.php" onmouseover="MM_swapImage('Image9','','img/third/btn_fix_dn.gif',1)" onmouseout="MM_swapImgRestore()"><img src="img/third/btn_fix_up.gif" name="Image9" width="90" height="90" border="0" id="Image9" /></a></td>
        <td width="30"><p><div id="apDiv1">
          <div id="apDiv2">
            <table width="290" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <th width="5" align="left" valign="top" bgcolor="#000000" scope="row"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side.gif" alt="a" width="3" height="95" vspace="0" border="0" align="left" /></a></th>
                <td height="95" bgcolor="#000000"><a href="QandA.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image15','','img/third/btn_list_dn.gif',1)"><img src="img/third/btn_list_up.gif" alt="a" name="Image15" width="90" height="90" border="0" id="Image15" /></a></td>
                <td width="5" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><a href="rule.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image17','','img/third/btn_rule_dn.gif',1)"><img src="img/third/btn_rule_up.gif" alt="a" name="Image17" width="90" height="90" border="0" id="Image17" /></a></td>
                <td width="5" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><a href="info.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image16','','img/third/btn_info_dn.gif',1)"><img src="img/third/btn_info_up.gif" alt="a" name="Image16" width="90" height="90" border="0" id="Image16" /></a></td>
                <td width="5" bgcolor="#000000"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side.gif" alt="a" width="3" height="95" vspace="0" border="0" align="right" /></a></td>
              </tr>
              <tr>
                <th height="3" colspan="7" align="left" valign="top" scope="row"><a href="javascript:;" onmouseover="MM_showHideLayers('apDiv1','','show','apDiv2','','hide')"><img src="img/third/side2.gif" alt="a" width="290" height="3" border="0" /></a></th>
              </tr>
              <tr>
                <th height="9" colspan="7" align="center" valign="top" scope="row">&nbsp;</th>
              </tr>
            </table>
          </div>
          <a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image23','','img/third/arrow_up(3).gif',1)"><img src="img/third/arrow_dn(3).gif" name="Image23" width="30" height="70" border="0" id="Image23" onmousedown="MM_showHideLayers('apDiv2','','show')" /></a></div></p></td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th height="389" align="left" valign="top" style="height: 389px; color: #FFF;" scope="row"><table width="100%" height="368" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <th width="300" height="368" align="center" valign="top" style="" scope="row">&nbsp;　　　　　　
          <p class="ggg">視聽室。請選擇想預約的時間          </p>
          <table width="502" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <th scope="row"> <?php
header("content-type:text/html;charset=utf-8");
?>
                <style>
form{
    margin:0px;
    padding:0px;
}
td{
    text-align:center;
    width:61px;
}
                </style>
<?php
if(!empty($_GET)){
    $year = $_GET['year'];
    $month = $_GET['month'];
	$year = str_pad($year,2,'0',STR_PAD_LEFT);
	$month = str_pad($month,2,'0',STR_PAD_LEFT);
}
if(empty($year)){
    $year = date('Y');
}

if(empty($month)){
    $month = date('m');
}

$today = date('d');
$m = date('m');
$y = date('Y');
$h = date('H');
$mi = date('i');
$all = $y.$m.$today;
$nowtime = $h.$mi;
$todaytime = $all.$nowtime;
//echo $all;
//echo "<font color=\"green\">$todaytime</font>";
$start_weekday = date('w',mktime(0,0,0,$month,1,$year));
$start_weekday = str_pad($start_weekday,2,'0',STR_PAD_LEFT);
//echo $start_weekday;
//$target_d = mktime(0,0,0,$month, 1,$year);
//echo "target_d " + $target_d;
$days = date('t',mktime(0,0,0,$month,1,$year));
$days = str_pad($days,2,'0',STR_PAD_LEFT);
//echo $days;
$week = array('星期日','星期一','星期二','星期三','星期四','星期五','星期六');
$i = 0;
$k = 1;
$j = 0;


echo '<table border = "1">';

echo '<tr>';
echo "<td><a href=?".lastMonth($year,$month).">".'上個月'.'</a></td>';
echo '<td colspan = 5 style = "text-align:center">'.$year.'年'.$month.'月'.'</td>';
echo "<td><a href=?".nextMonth($year,$month).">".'下個月'.'</a></td>';
echo '</tr>';
echo '<tr>';
for($i = 0;$i < 7;$i++){
    echo '<td>'.$week[$i].'</td>';
}
echo '</tr>';
echo '<tr>';
for($j = 0;$j < $start_weekday;$j++){
    echo '<td style="color:#000000">'.$j.'</td>';
}

while($k <= $days){
	$k = str_pad($k,2,'0',STR_PAD_LEFT);
    if($k == date('d')){
        echo '<td><a href=ordermovie.php?'.nowYear($year,$month,$k).'>'.$k.'</a></td>';
    }else{
        echo '<td><a href=ordermovie.php?'.nowYear($year,$month,$k).'>'.$k.'</a></td>';
    }
    if(($j+1) % 7 == 0){
        echo '</tr><tr>';
    }
    $j++;
    $k++;
}
while($j % 7 != 0){
    echo '<td style="color:#000000">'.$j.'</td>';
    $j++;
}
echo '</tr>';

function nowYear($year,$month,$k){
 $year = $year;
 return "year=$year&month=$month&day=$k";
}
function lastYear($year,$month,$k){
 $year = $year-1;
 return "year=$year&month=$month&day=$k";
}
function lastMonth($year,$month){
 if($month == 1){
  $year = $year -1;
  $month = 12;
  $month = str_pad($month,2,'0',STR_PAD_LEFT);
 }else{
  $month--;
 }
 return "year=$year&month=$month";
}
function nextYear($year,$month){
 $year = $year+1;
 return "year=$year&month=$month";
}
function nextMonth($year,$month){
 if($month == 12){
  $year = $year +1;
  $month = 1;
  $month = str_pad($month,2,'0',STR_PAD_LEFT);
 }else {
  $month++;
 }
 return "year=$year&month=$month";
}
 
?></th></table> 
        </tr>
          </table></th>
        <th width="35%" height="368" align="center" valign="top" style="" scope="row">
          <p>&nbsp;          </p>
          
          <p>
          <?php   
if (isset($_GET['year'])) {
  $colname_Recordset1 = $_GET['year'];
  $colname_Recordset2 = $_GET['month'];
  $colname_Recordset3 = $_GET['day'];
  $QQ = "/";
  $colname_Recordset4 = $colname_Recordset1.$colname_Recordset2.$colname_Recordset3;
  $aa = 800;
  $a = 0;
  $bb = 1000;
  $colname_Recordset5 = $colname_Recordset4.$a.$aa;
  $cc = 1200;
  $dd = 1400;
  $ee = 1600;
  $ff = 1800;
  $gg = 2000;
}
        ?>
          <?php echo $colname_Recordset1.$QQ?><?php echo $colname_Recordset2.$QQ?><?php echo $colname_Recordset3 ?></p>
          <form action="<?php echo $editFormAction; ?>" id="form1" name="form1" method="POST">
            <div id="apDiv4">
              <p>
                <label>
                  <input name="year" type="text" id="year" value="<?php echo $colname_Recordset1; ?>" readonly="readonly" />
                </label>
                <input name="month" type="text" id="month" value="<?php echo $colname_Recordset2; ?>" readonly="readonly" />
                <input name="day" type="text" id="day" value="<?php echo $colname_Recordset3; ?>" readonly="readonly" />
                <input name="order_name" type="text" id="order_name" value="<?php echo $row_RecUser['m_username']; ?>" readonly="readonly" />
                <input name="o_time" type="text" id="o_time" value="<?php echo $colname_Recordset1; ?><?php echo $colname_Recordset2; ?><?php echo $colname_Recordset3; ?>" readonly="readonly" />
              </p>
</div>
            <table width="100%" border="0" align="left" cellspacing="0" cellpadding="0">
              <tr>
                <th scope="row">
                <div id="apDiv5"><?php 
				$colname_Recordset1 = "-1";
if (isset($_GET['year'])) {
  $colname_Recordset1 = $_GET['year'];
  $colname_Recordset2 = $_GET['month'];
  $colname_Recordset3 = $_GET['day'];
}
mysql_select_db($database_connSQL, $connSQL);
$query_RecOrderTime = sprintf("SELECT * FROM `order` WHERE year=$colname_Recordset1 and month=$colname_Recordset2 and day=$colname_Recordset3");
$RecOrderTime = mysql_query($query_RecOrderTime, $connSQL) or die(mysql_error());
$row_RecOrderTime = mysql_fetch_assoc($RecOrderTime);
$totalRows_RecOrderTime = mysql_num_rows($RecOrderTime);
				?></div>
               <?php  if ($all > $colname_Recordset4) 
				  { echo("時間已經過了喔~");echo "<script>alert('請選擇今天以後的時間');</script>";
} else {
?>
				<?php  
				$ordername = $row_RecUser['m_username']; 
				$sql="SELECT *,count(*) as inname FROM `order` WHERE year=$colname_Recordset1 and month=$colname_Recordset2 and day=$colname_Recordset3 and order_name='$ordername' GROUP BY `order_name`";
				$result = mysql_query($sql);
				while($row=mysql_fetch_array($result)){
					 $redname = $row["order_name"];
					}
					if ($ordername == $redname)
					{  ?>
					<font color=red><?php echo ("您已經預約過了，預約的時間為<br>");?></font>
					  <font color=red><?php echo $row_RecOrderTime['order_time'] ?></font>
					  <?php echo ("<br>如欲預約其他時段，請洽櫃檯");?>
					  <p>&nbsp;</p><input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $row_RecOrderTime['order_id']; ?>" />
				<a href="ordermovie.php?dele=true&amp;order_id=<?php echo $row_RecOrderTime['order_id']; ?>" onclick="tfm_confirmLink('您確定要取消預約嗎??');return document.MM_returnValue">取消預約</a>
                <?php
					}
					else{
				?>
				
<table width="270" border="0" align="left" cellpadding="0" cellspacing="0" class="qwertyu">
                <tr>
                   
				  
                    <th width="265" align="left" scope="row">
                    <?php if ($todaytime > $colname_Recordset5) {echo ("");} else {?>
					<input  name="order_time" type="radio" id="radio"value="08:00~10:00" /> 
					<?php } ?>
                     08:00~10:00
                     <?php if ($todaytime > $colname_Recordset5) {echo ("");} else {?>
                    <?php  
					$sql="SELECT *,count(*) as total FROM `order` WHERE year=$colname_Recordset1 and month=$colname_Recordset2 and day=$colname_Recordset3 and order_time='08:00~10:00' GROUP BY `order_time`";
					$result = mysql_query($sql);
					while($row=mysql_fetch_array($result)){
					 $one = $row["total"];
					}
					
					if ($one ==NULL) { echo("<font color=green >可預約</font>");} else {echo("<font color=red>$one 人已預約，可後補</font>"); } ?></th><?php } ?>
                </tr>
                  <tr>
                    <th align="left" scope="row">
                    <?php if ($todaytime > $colname_Recordset4.$bb) {echo ("");} else {?>
                     <input  name="order_time" type="radio" id="radio9" value="10:00~12:00" />
					 <?php } ?>
                    10:00~12:00
                    <?php if ($todaytime > $colname_Recordset4.$bb) {echo ("");} else {?>
                    <?php 
					$sql="SELECT *,count(*) as total FROM `order` WHERE year=$colname_Recordset1 and month=$colname_Recordset2 and day=$colname_Recordset3 and order_time='10:00~12:00' GROUP BY `order_time`";
					$result = mysql_query($sql);
					while($row=mysql_fetch_array($result)){
   					 //echo $row["total"];
					 $two = $row["total"];
					}
					
					
					if ($two ==NULL) { echo("<font color=green>可預約</font>");} else {echo("<font color=red>$two 人已預約，可後補</font>"); } ?></th><?php } ?>
                  </tr>
                  <tr>
                    <th align="left" scope="row">
                    <?php if ($todaytime > $colname_Recordset4.$cc) {echo ("");} else {?> 
                    <input  name="order_time" type="radio" id="radio10" value="12:00~14:00" />
					<?php } ?>
                    12:00~14:00
                    <?php if ($todaytime > $colname_Recordset4.$cc) {echo ("");} else {?> 
                      <?php 
					  $sql="SELECT *,count(*) as total FROM `order` WHERE year=$colname_Recordset1 and month=$colname_Recordset2 and day=$colname_Recordset3 and order_time='12:00~14:00' GROUP BY `order_time`";
					$result = mysql_query($sql);
					while($row=mysql_fetch_array($result)){
   					 //echo $row["total"];
					 $three = $row["total"];
					}
					  if ($three ==NULL) { echo("<font color=green>可預約</font>");} else {echo("<font color=red>$three 人已預約，可後補</font>"); } ?></th><?php } ?>
                  </tr>
                  <tr>
                    <th align="left" scope="row"> 
                    <?php if ($todaytime > $colname_Recordset4.$dd) {echo ("");} else {?>
                    <input  name="order_time" type="radio" id="radio11" value="14:00~16:00" />
					<?php } ?>
                    14:00~16:00
                    <?php if ($todaytime > $colname_Recordset4.$dd) {echo ("");} else {?>
                      <?php 
					  $sql="SELECT *,count(*) as total FROM `order` WHERE year=$colname_Recordset1 and month=$colname_Recordset2 and day=$colname_Recordset3 and order_time='14:00~16:00' GROUP BY `order_time`";
					$result = mysql_query($sql);
					while($row=mysql_fetch_array($result)){
   					 //echo $row["total"];
					 $four = $row["total"];
					}
					  if ($four ==NULL) { echo("<font color=green>可預約</font>");} else {echo("<font color=red>$four 人已預約，可後補</font>"); } ?></th><?php } ?>
                  </tr>
                  <tr>
                    <th align="left" scope="row"> 
                    <?php if ($todaytime > $colname_Recordset4.$ee) {echo ("");} else {?>
                    <input  name="order_time" type="radio" id="radio12" value="16:00~18:00" />
					<?php } ?>
                    16:00~18:00
                    <?php if ($todaytime > $colname_Recordset4.$ee) {echo ("");} else {?>
                      <?php 
					  $sql="SELECT *,count(*) as total FROM `order` WHERE year=$colname_Recordset1 and month=$colname_Recordset2 and day=$colname_Recordset3 and order_time='16:00~18:00' GROUP BY `order_time`";
					$result = mysql_query($sql);
					while($row=mysql_fetch_array($result)){
   					 //echo $row["total"];
					 $five = $row["total"];
					}
					  if ($five ==NULL) { echo("<font color=green>可預約</font>");} else {echo("<font color=red>$five 人已預約，可後補</font>"); } ?></th><?php } ?>
                  </tr>
                  <tr>
                    <th align="left" scope="row"> 
                    <?php if ($todaytime > $colname_Recordset4.$ff) {echo ("");} else {?>
                    <input  name="order_time" type="radio" id="radio13" value="18:00~20:00" />
					<?php } ?>
                    18:00~20:00
                    <?php if ($todaytime > $colname_Recordset4.$ff) {echo ("");} else {?>
                      <?php 
					  $sql="SELECT *,count(*) as total FROM `order` WHERE year=$colname_Recordset1 and month=$colname_Recordset2 and day=$colname_Recordset3 and order_time='18:00~20:00' GROUP BY `order_time`";
					$result = mysql_query($sql);
					while($row=mysql_fetch_array($result)){
   					 //echo $row["total"];
					 $six = $row["total"];
					}
					  if ($six ==NULL) { echo("<font color=green>可預約</font>");} else {echo("<font color=red>$six 人已預約，可後補</font>"); } ?></th><?php } ?>
                  </tr>
                  <tr>
                    <th align="left" scope="row">
                    <?php if ($todaytime > $colname_Recordset4.$gg) {echo ("");} else {?> 
                    <input  name="order_time" type="radio" id="radio5" value="20:00~22:00" />
					<?php } ?>
                    20:00~22:00
                    <?php if ($todaytime > $colname_Recordset4.$gg) {echo ("");} else {?> 
					<?php 
					$sql="SELECT *,count(*) as total FROM `order` WHERE year=$colname_Recordset1 and month=$colname_Recordset2 and day=$colname_Recordset3 and order_time='20:00~22:00' GROUP BY `order_time`";
					$result = mysql_query($sql);
					while($row=mysql_fetch_array($result)){
   					 //echo $row["total"];
					 $seven = $row["total"];
					}
					if ($seven ==NULL) { echo("<font color=green>可預約</font>");} else {echo("<font color=red>$seven 人已預約，可後補</font>"); } ?>
                    </th><?php } ?>
                  </tr>
                </table> <p>
              <input type="submit" name="button2" id="button2" value="確定" />
            </p><?php }?> <?php } ?></th>
              </tr>
            </table>
            
            <input type="hidden" name="MM_insert" value="form1" />
            <input type="hidden" name="MM_insert" value="form1" />
          </form>
    <p><br>
      <a href="order.php"><img src="img/BTN/back.png" width="110" height="30" border="0" /></a></p></th>
  </tr>
</table></th>
  </tr>
  <tr>
<th height="29" style="background-position: center; background-image: url(img/third/dn_bar.gif); font-size: 12px; color: #FFF; font-family: '微軟正黑體';" scope="row">版權所有◎2010 超媒體管家企業有限公司</th>
  </tr>
</table>
</body>
</html>
